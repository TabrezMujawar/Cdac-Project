
function LogoutComponent()
{
  sessionStorage.removeItem("role");
  sessionStorage.removeItem("details");
  sessionStorage.removeItem("appointmentID");
  window.location.href="http://localhost:3000";

}

export default LogoutComponent;