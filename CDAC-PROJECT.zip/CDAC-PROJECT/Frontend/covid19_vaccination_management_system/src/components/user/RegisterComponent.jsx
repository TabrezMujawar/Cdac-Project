import React from "react";
import UserService from "../../service/UserService.js";
import {none, heart_disease, respiratory_disease, other_disease} from "../../constants/disease-type.js";
import {male, female, other} from "../../constants/gender-type.js";

class RegisterComponent extends React.Component

{
    constructor(props){
        super(props);
        this.state ={
            medical_history: '',
            name: '',
            dob: '',
            gender: '',
            email: '',
            password: '',
            address: '',
            contact_no: '',
            aadharNumber: ''
        }
        this.saveUser = this.saveUser.bind(this);
      
    }
  
    validMedicalHistory()
    {
      if(this.state.medical_history==='')
      {
        this.setState({medicalValidatedMessage:"Please select medical history"});
        
        return false;
      }
      else
      {
        this.setState({medicalValidatedMessage:""});
       
        return true;
      }
    }
  
    validName()
    { 
     if(this.state.name==='')
     {
       this.setState({nameValidatedMessage:"Please enter valid name"});
       
       return false;
     }
     else
     {
       this.setState({nameValidatedMessage:""});
      
       return true;
     }
    }

    validDOB()
    { 
     if(this.state.dob==='')
     {
       this.setState({dobValidatedMessage:"Please enter date of birth"});
       
       return false;
     }
     else
     {
       this.setState({dobValidatedMessage:""});
      
       return true;
     }
    }


    validEmail()
    { 
     if(this.state.email==='' || !this.state.email.includes("@") || !this.state.email.endsWith(".com"))
     {
       this.setState({emailValidatedMessage:"Please enter valid email"});
       
       return false;
     }
     
       this.setState({emailValidatedMessage:""});
       return true;
     
    }

    validPassword()
    {
     if(this.state.password==='' || !(this.state.password.length<=10 && this.state.password.length>=5) )
     {
       this.setState({passwordValidatedMessage:"Password must contain at least 5 character and less than 10 characters"});
       return false;
     }
     this.setState({passwordValidatedMessage:""});
     return true;
    }

    validAddress()
    {
     if(this.state.address==='')
     {
       this.setState({addressValidatedMessage:"Please enter valid address"});
       return false;
     }
     this.setState({addressValidatedMessage:""});
     return true;
    }

    validContact()
    {
      if(this.state.contact_no==='' ||  !this.state.contact_no.length===10)
     {
       this.setState({contactValidatedMessage:"Please enter valid mobile number"});
       return false;
     }
     this.setState({contactValidatedMessage:""});
     return true;
    }

    validAadhar()
    { 
      if(this.state.aadharNumber==='')
    {
      this.setState({aadharValidatedMessage:"Please enter valid aadhar number"});
      return false;
    }
    this.setState({aadharValidatedMessage:""});
    return true;
   }



   validUser()
    {
        let isValid=true;
        if(!this.validMedicalHistory())
        {
          isValid=false;
        }
        if(!this.validName())
        {
          isValid=false;
        }
        if(!this.validDOB()) 
        {
          isValid=false;
        }  
        if(!this.validEmail())
        {
          isValid=false;
        } 
        if(!this.validPassword())
        {
          isValid=false;
        }             
        if(!this.validAddress())
        {
          isValid=false;
        } 
        if(!this.validContact())
        {
          isValid=false;
        }
        if(!this.validAadhar()) 
        {
          isValid=false;
        }
       return isValid;
   }
    
    

    saveUser = (e) => {
      if(this.validUser())
      {
      e.preventDefault();
        let user = {medical_history: this.state.medical_history, name: this.state.name, dob: this.state.dob, gender: this.state.gender, email: this.state.email, password: this.state.password, address: this.state.address, contact_no: this.state.contact_no, aadharNumber: this.state.aadharNumber};
        
        UserService.addUser(user)
        
            .then(res => {
               document.getElementById("message").style.color="green";
                this.setState({message : 'User added successfully.'});
                this.props.history.push('/user');
            })
            .catch(err=>
              { 
                document.getElementById("message").style.color="red";
                this.setState({message : 'Registration failed'});
              })
    }
  }
     onChange = (e) =>
    this.setState({ [e.target.name]: e.target.value });
            
      render()
    {
      
        return( 
            
           <div id="user_register" class="row">
               
               <center><h4 id="message">{this.state.message}</h4></center>
                   <center><h4 id="errorMessage">{this.state.errorMessage}</h4></center>
           
            <h4 className="text-center">Register User</h4>
          
            <center><div class="card" id="userRegisterCard">
             
            <form className="row g-1 needs-validation" id="userRegisterform" novalidate>
           <div class="row">
           <center>  <div class="col-md-3">
              <label for="validationCustom01" class="form-label">Medical History <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
              <select class="form-select" name="medical_history" onChange={this.onChange} aria-label="Default select example" id="validationCustom01" required>
                <option selected disabled value="">Select</option>
                <option value={none} onChange={this.onChange}>None</option>
                <option value={heart_disease} onChange={this.onChange}>Heart disease</option>
                <option value={respiratory_disease} onChange={this.onChange}>Respiratory disease</option>
                <option value={other_disease} onChange={this.onChange}>Other disease</option>
                </select>
                <p id="errors">{this.state.medicalValidatedMessage}</p>
                  </div>  </center> 
              </div>
             <div class="row g-2">
            <div class="col-md-6">
                <label for="name" class="form-label">Name <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input placeholder="Full Name"  id="name" ref={this.callRefInput} name="name" className="form-control" value={this.state.name} onChange={this.onChange} required/>
                <p id="errors">{this.state.nameValidatedMessage}</p>
            </div>

            <div className="col-md-6">
            <label for="dob" class="form-label">Date of Birth <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input type="date" id="dob" name="dob" className="form-control" value={this.state.dob} onChange={this.onChange} required/>
                <p id="errors">{this.state.dobValidatedMessage}</p>
            </div>
            </div>
        
      
            <div class="row g-3">
            <div className="col-md-6">
            <label for="gender" id="labelGender" class="form-label">Gender</label>  
            <div role="group" name="gender" aria-label="Basic radio toggle button group" required>
            
              <input type="radio" className="btn-check" name="gender" id="btnradio1" value={male} autocomplete="off"  onChange={this.onChange}/>
              <label class="btn btn-outline-primary" for="btnradio1">Male</label>
           
             <input type="radio" className="btn-check" name="gender" id="btnradio2" value={female} autocomplete="off" onChange={this.onChange} />
             <label class="btn btn-outline-primary" for="btnradio2">Female</label>
             
           <input type="radio" className="btn-check" name="gender" id="btnradio3" value={other} autocomplete="off" onChange={this.onChange}/>
           <label class="btn btn-outline-primary" for="btnradio3">Other</label>
           </div>
         </div>
            <div className="col-md-6">
            <label for="email" class="form-label">Email <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input placeholder="Email"  id="email" name="email" className="form-control" value={this.state.email} onChange={this.onChange} required/>
                <p id="errors">{this.state.emailValidatedMessage}</p>
            </div>
        </div>

        <div className="row g-2">
            <div className="col-md-6">
            <label for="password" class="form-label">Password <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input type="password" id="password" placeholder="password" name="password" className="form-control" value={this.state.password} onChange={this.onChange} required/>
                <p id="errors">{this.state.passwordValidatedMessage}</p>
            </div>

            <div className="col-md-6">
            <label for="address" class="form-label">Address <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <textarea rows="2" id="address" className="form-control" placeholder="Enter Address" cols="20" name="address" value={this.state.address} onChange={this.onChange} required></textarea>
                <p id="errors">{this.state.addressValidatedMessage}</p>
           </div>
        </div>

       <div className="row g-2">
            <div className="col-md-6">
            <label for="contact_no" class="form-label">Contact <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input type="text"  placeholder="Enter mobile number" name="contact_no" id="contact_no" className="form-control" value={this.state.contact_no} onChange={this.onChange} required/>
                <p id="errors">{this.state.contactValidatedMessage}</p>
            </div>
            <div className="col-md-6">
            <label for="aadharNumber" class="form-label">Aadhar number <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input type="text" id="aadharNumber" placeholder="Enter aadhar number" name="aadharNumber" className="form-control" value={this.state.aadharNumber} onChange={this.onChange} required/>
                <p id="errors">{this.state.aadharValidatedMessage}</p>
          </div>
       </div>
           <div className="row g-2">
            <center><button type="button" id="registerButton" class="btn btn-primary " onClick={this.saveUser}>Register</button></center>                                                                                     
            </div>
          </form>
          </div></center>
        </div>
        
        )
    }


}

export default RegisterComponent;