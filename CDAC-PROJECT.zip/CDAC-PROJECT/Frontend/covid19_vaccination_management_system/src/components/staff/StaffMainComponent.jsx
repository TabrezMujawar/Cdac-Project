import React from 'react';

class StaffMainComponent extends React.Component
{
   render()
   {
    let details=JSON.parse(sessionStorage.getItem("details"));
            return (
                 <div id="main_nav" className="row">
                       <div class="container-fluid">
                       <div class="col-sm-3 col-md-3 sidebar">
                       <button className="navbar-toggler" type="button" href="#navbarDropdown" data-bs-toggle="collapse" data-bs-target="#navbarDropdown" aria-controls="navbarDropdown" aria-expanded="false" aria-label="Toggle navigation">
                             <span className="navbar-toggler-icon"></span>
                             </button>
                             <img src="./icons/staff-logo.png" alt="logo" id="user-icon"></img>
                             <a id="navbar-brand" class="navbar-brand" href="/staffpage">Staff</a>
                            <ul class="nav-sidebar">
                          
                              <div class="row">
                              <li class="nav-item ">
                                <a class="nav-link active"  id="nav-link" aria-current="page" href="/">Go to Homepage</a>
                              </li>
                              </div>
                              <li class="nav-item ">
                                <a  class="nav-link" id="nav-link" href="/staff_profile">Staff Profile</a>
                              </li> 
                              <li class="nav-item">
                                <a class="nav-link" id="nav-link" href="/staff_update">Update Profile</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link"  id="nav-link" href="/change_password">Change password</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link" id="nav-link" href="/logout">Logout</a>
                              </li>
                            </ul>
                            </div>
                         </div>
                           </div>
                           
                          

                           
                         
            )
           

   }

}

export default StaffMainComponent;