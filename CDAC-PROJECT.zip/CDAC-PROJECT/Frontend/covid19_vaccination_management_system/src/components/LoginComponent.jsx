import React from 'react';
import LoginService from "../service/LoginService";
import {admin,user,staff} from "../constants/roles";
import ForgetPasswordService from '../service/ForgetPasswordService';

class LoginComponent extends React.Component
{
 
      constructor(props)
      {
          super(props)
           this.state={
            role: "",  
            username: "",
            password: "",
            subject: "",
            message: ""     
          }
         this.authenticate=this.authenticate.bind(this);
         this.sendResetMail=this.sendResetMail.bind(this);
      }

      componentDidMount()
      {
        this.setState({subject:"Reset password", message:"http://localhost:3000/forget_password"})

      }
    
      validRole()
      {
         if(this.state.role==='')
         {
           this.setState({validateRolemessage:"Please select role"});
           return false
         }
         else  
         { 
         this.setState({validateRolemessage:""});
          return true;
         }
      }

      validUsername()
    { 
     if(this.state.username==='' || !this.state.username.includes("@") || !this.state.username.endsWith(".com"))
     {
       this.setState({usernameValidatedMessage:"Please enter valid email"});
       
       return false;
     }
     
       this.setState({usernameValidatedMessage:""});
       return true;
     
    }

    validDetails()
    {
        let isValid=true;
        
        if(!this.validUsername())
        {
          isValid=false;
        }
        if(!this.validRole())
        {
            isValid=false;
        }    
    
        return isValid;
    }    


      sendResetMail=(e)=>
      {
      
         if(this.validDetails())
         {
        let d={role:this.state.role, destEmail:this.state.username,subject:this.state.subject,message:this.state.message}
        console.log("emailDetails"+d);
          ForgetPasswordService.sendResetlink(d)
             .then(res=>
               {
                  document.getElementById("message").style.color="green";
                  this.setState({msg:"Reset password link is sent to your registered mail id"});
               }
             )
             .catch(err=>{
               console.log(err);
              document.getElementById("message").style.color="red";
              this.setState({msg:"This email id not registered"});
             })
            }
  
      }
    
            
                    



    authenticate = (e) => {
      if(this.validRole())
      {
        e.preventDefault();
        let role=this.state.role;
        let uname=this.state.username;
        let pass=this.state.password;
         LoginService.authenticateRole(role,uname,pass)
                  .then(res => {
                            console.log(res.data);
                            sessionStorage.setItem("details",JSON.stringify(res.data));
                            sessionStorage.setItem("role",role);
                            sessionStorage.setItem("message","Login Successful");
                            if(role==="ADMIN")
                            {
                           
                           this.props.history.push("/adminpage");
                            }
                            else if(role==="USER")
                            {
                           
                            this.props.history.push("/userpage")   
                            }
                            else
                            {
                            this.props.history.push("/staffpage");
                            }
                  })
                   .catch (err =>{
                       this.setState({errMessage:"Invalid username or password"});
                   }
                    )
             }     
        }  
 

        onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });

   render()
   {
            return (
                       <div id="login" className="row g-3">
                            <center><h4 id="message">{this.state.msg}</h4></center>
                             <center><label class="h1" style={{fontFamily:'monospace',fontWeight:'bold',color:"blue"}}>L<span style={{color:"red"}}>o</span><span style={{color:"green"}}>g</span><span style={{color:"red"}}>i</span><span style={{color:"blue"}}>n</span></label></center>
                                <center><h4 id="error">{this.state.errMessage}</h4></center>
                                 <center><div class="card" id="loginCard">
 
                                   <center><form className="row" id="loginForm">

                              <center>  <div class="col-md-3">
                                <label for="role" class="form-label">Role</label>
                                <select class="form-select" name="role" onChange={this.onChange} aria-label="Default select example" id="role" required>
                                    <option selected disabled value="">Select role</option>
                                    <option value={admin} onChange={this.onChange}>Admin</option>
                                    <option value={user} onChange={this.onChange}>User</option>
                                    <option value={staff} onChange={this.onChange}>Staff</option>
                                    </select>
                                    <p id="errors">{this.state.validateRolemessage}</p>
                                    </div></center>

                                    <div class="row g-2">
                                  <div class="col-md-3">  
                                    <label for="username" class="form-label">Username</label>
                                    </div>
                                    <div class="col-md-8">  
                                    <input type="email" placeholder="Enter email" class="form-control" id="username" name="username" value={this.state.username} onChange={this.onChange} aria-describedby="emailHelp" required/>
                                    <p id="errors">{this.state.usernameValidatedMessage}</p>
                                    </div>
                                </div> 
                                
                                <div class="row g-2">
                                <div class="col-md-3">
                                    <label for="password" class="form-label">Password</label>
                                    </div>
                                    <div class="col-md-8">
                                    <input type="password" placeholder="Enter password"  name="password" class="form-control" value={this.state.password} id="password" onChange={this.onChange}  required/>
                                    <p id="errors">{this.state.passwordValidatedMessage}</p>
                                </div>
                                </div>

                        
                               
                                <div class="row g-1" style={{paddingLeft:"5rem"}}>
                               <div class="col-6" >
                             <button type="button"   id="loginButton"class="btn btn-primary" onClick={this.authenticate}>Login</button>
                               </div>
                             <div class="col-6"  style={{paddingRight:"6rem"}} >
                             <button type="button" id="forgetButton"class="btn btn-primary" onClick={this.sendResetMail} >Forget password</button>
                                </div> 
                                </div>
                                </form> </center> 
                               </div></center>
                       </div>

            )
           

   }

}

export default LoginComponent;