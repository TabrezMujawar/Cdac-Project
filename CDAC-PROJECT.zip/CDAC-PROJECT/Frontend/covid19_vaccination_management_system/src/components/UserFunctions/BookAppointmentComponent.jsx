import { error } from 'jquery';
import React from 'react';
import AppointmentService from '../../service/AppointmentService.js';
import UserMainComponent from '../user/UserMainComponent';
 const slots=[
  "TIMESLOT1_9AM_TO_10AM",
  "TIMESLOT2_10AM_TO_11AM",
  "TIMESLOT3_11AM_TO_12PM",
  "TIMESLOT4_12PM_TO_1PM",
  "TIMESLOT5_1PM_TO_2PM",
  "TIMESLOT6_2PM_TO_3PM",
  "TIMESLOT7_3PM_TO_4PM",
  "TIMESLOT8_4PM_TO_5PM",
  "TIMESLOT9_5PM_TO_6PM",
  "TIMESLOT10_6PM_TO_7PM",
]
class BookAppointmentComponent extends React.Component
{
   
  constructor(props){
    super(props)
    this.state ={
        appId: '',
        booking_date: '',
        booking_time: '',
        status: '',
        appointment: '',
        message: null
    }
    this.bookAppointment = this.bookAppointment.bind(this);
  }

componentDidMount()
{
    this.showDate();

    
}
  showDate()
  {
    const date = new Date();
    date.setDate(date.getDate()+1);
    this.setState({booking_date:date.toISOString().slice(0,10)});
  }


  validBookingTime()
  { 
    if(this.state.booking_time==='')
    {
    this.setState({timeValidatedMessage:"Please enter booking time"});
    return false;
    }
  this.setState({timeValidatedMessage:""});
  return true;
  }

  
  bookAppointment=(e)=>{

     
    if(this.validBookingTime())
    {

       e.preventDefault();
       let userId=JSON.parse(sessionStorage.getItem("details")).result.id;
       console.log(userId);
       let appointment={booking_date: this.state.booking_date, booking_time: this.state.booking_time}
        console.log(appointment);
  
       AppointmentService.addAppointment(userId,appointment)
          .then(res=> {
            document.getElementById("success").style.color="green";
              this.setState({
                  appointment: res.data,
                  status:"BOOKED",
                  message:"Appointment booked successfully"
              })

              sessionStorage.setItem("appointmentID",res.data.id);
              
          })
           .catch( err=> {
            console.log("In catch "+err)
            document.getElementById("success").style.color="red";
             console.log("app :"+this.state.appointment)
                    this.setState({
                       message:"Failure due to one of these reasons ....... ! 1.You can't book more than one appointment 2.This booking slot is already book"
                    })
             }) 
           
            
     }   
    
  
    }

       onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });

   render()
   {
       
            return (
                <div class="m row g-2">
                   <div className="col-4">
                  <UserMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                      <div className="row g-2">
                         <h4 id="success">{this.state.message}</h4>
                      </div>
                      <h2 className="h2">Book Appointment</h2>
                      <p className="row-md-2" style={{color:'blue'}}>Note :To book new appointment cancel the old appointment if you have booked and you can only able to book an appointment for tomorrow</p>
                    <div className="row g-1">
                <center><form>
                    <div className="form-group" id="appointment-form">
                       <label for="booking_date" class="form-label">Booking date:</label>
                       <input type="date" id="booking_date" name="booking_date" readOnly="true"  value={this.state.booking_date} defaultValue={this.state.booking_date} className="form-control" onChange={this.onChange} required />
                    </div>
                     
             <div className="form-group"  id="appointment-form">
                        <label for="booking_time" class="form-label">Booking time slot</label>
                        <select class="form-select" name="booking_time" onChange={this.onChange} aria-label="Default select example" id="booking_time" required>
                            <option selected disabled value="">Select</option>
                            <option value={slots[0]} onChange={this.onChange}>TIMESLOT 1 :  9 AM - 10 AM </option>
                            <option value={slots[1]} onChange={this.onChange}>TIMESLOT 2 : 10 AM - 11 AM </option>
                            <option value={slots[2]} onChange={this.onChange}>TIMESLOT 3 : 11 AM - 12 PM </option>
                            <option value={slots[3]} onChange={this.onChange}>TIMESLOT 4 : 12 PM - 1 PM </option>
                            <option value={slots[4]} onChange={this.onChange}>TIMESLOT 5 :  1 PM - 2 PM </option>
                            <option value={slots[5]} onChange={this.onChange}>TIMESLOT 6 :  2 PM - 3 PM </option>
                            <option value={slots[6]} onChange={this.onChange}>TIMESLOT 7 :  3 PM - 4 PM </option>
                            <option value={slots[7]} onChange={this.onChange}>TIMESLOT 8 :  4 PM - 5 PM </option>
                            <option value={slots[8]} onChange={this.onChange}>TIMESLOT 9 :  5 PM - 6 PM </option>
                            <option value={slots[9]} onChange={this.onChange}>TIMESLOT 10 : 6 PM - 7 PM </option>
                            </select>
                       <p id="errors">{this.state.timeValidatedMessage}</p>
                    </div>
              
            
                <div className="col-md-4">
                     <button className="btn btn-success" style={{width:'100px'}} onClick={this.bookAppointment}>Book</button>
                     </div>
                    
             </form></center>
              </div>
             </div>
            </div>
                    

            )
           

   }
  
}

export default BookAppointmentComponent;