import React, { Component } from 'react'
import {male, female, other} from "../../constants/gender-type.js";
import {none, heart_disease, respiratory_disease} from "../../constants/disease-type.js";
import UserService from '../../service/UserService';
import UserMainComponent from '../user/UserMainComponent';

class UpdateUserDetailsComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
        id: '',    
        medical_history: '',
        name: '',
        dob: '',
        gender: '',
        email: '',
        address: '',
        contact_no: '',
        aadharNumber: ''
           
        }
        this.saveUser = this.saveUser.bind(this);
        this.loadUser = this.loadUser.bind(this);
    }

    validMedicalHistory()
    {
      if(this.state.medical_history==='')
      {
        this.setState({medicalValidatedMessage:"Please select medical history"});
        
        return false;
      }
      else
      {
        this.setState({medicalValidatedMessage:""});
       
        return true;
      }
    }
  
    validName()
    { 
     if(this.state.name==='')
     {
       this.setState({nameValidatedMessage:"Please enter valid name"});
       
       return false;
     }
     else
     {
       this.setState({nameValidatedMessage:""});
      
       return true;
     }
    }

    validDOB()
    { 
     if(this.state.dob==='')
     {
       this.setState({dobValidatedMessage:"Please enter date of birth"});
       
       return false;
     }
     else
     {
       this.setState({dobValidatedMessage:""});
      
       return true;
     }
    }


    validEmail()
    { 
     if(this.state.email==='' || !this.state.email.includes("@") || !this.state.email.endsWith(".com"))
     {
       this.setState({emailValidatedMessage:"Please enter valid email"});
       
       return false;
     }
     
       this.setState({emailValidatedMessage:""});
       return true;
     
    }

    

    validAddress()
    {
     if(this.state.address==='')
     {
       this.setState({addressValidatedMessage:"Please enter valid address"});
       return false;
     }
     this.setState({addressValidatedMessage:""});
     return true;
    }

    validContact()
    {
      if(this.state.contact_no==='' ||  !this.state.contact_no.length===10)
     {
       this.setState({contactValidatedMessage:"Please enter valid mobile number"});
       return false;
     }
     this.setState({contactValidatedMessage:""});
     return true;
    }

    validAadhar()
    { 
      if(this.state.aadharNumber==='')
    {
      this.setState({aadharValidatedMessage:"Please enter valid aadhar number"});
      return false;
    }
    this.setState({aadharValidatedMessage:""});
    return true;
   }



   validUser()
    {
        let isValid=true;
        if(!this.validMedicalHistory())
        {
          isValid=false;
        }
        if(!this.validName())
        {
          isValid=false;
        }
        if(!this.validDOB()) 
        {
          isValid=false;
        }  
        if(!this.validEmail())
        {
          isValid=false;
        } 
                 
        if(!this.validAddress())
        {
          isValid=false;
        } 
        if(!this.validContact())
        {
          isValid=false;
        }
        if(!this.validAadhar()) 
        {
          isValid=false;
        }
       return isValid;
   }
    
         
        componentDidMount() {
            this.loadUser();
        }

         loadUser() {
      let details=JSON.parse(sessionStorage.getItem("details"));
      console.log("Id : "+details.result.id);
      let userID=details.result.id;
     // AdminService.getAdmin(adminID)
          fetch("http://localhost:6060/user/"+userID)
            .then(async (res)=> {
                console.log("In User");
                 let user =  await res.json();
                console.log("User : "+user.result);
                this.setState({
                    id: user.result.id,
                    medical_history: user.result.medical_history,
                    name: user.result.name,
                    dob: user.result.dob,
                    gender: user.result.gender,
                    email: user.result.email,
                    address: user.result.address,
                    contact_no: user.result.contact_no,
                    aadharNumber: user.result.aadharNumber
                })
            })
            
           
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    saveUser = (e) => {
        if(this.validUser())
        {
        e.preventDefault();
        let user = {id: this.state.id,medical_history: this.state.medical_history, name: this.state.name, dob: this.state.dob, gender: this.state.gender, email: this.state.email, password: this.state.password, address: this.state.address, contact_no: this.state.contact_no, aadharNumber: this.state.aadharNumber};      
        UserService.editUser(user)   
        .then(res => {
                document.getElementById("success").style="green";
                this.setState({message : 'User updated successfully.'});
                this.props.history.push('/user_update');
            })
            .catch(err =>{
              console.log(err);
              document.getElementById("success").style="red";
              this.setState({message : 'User updation failed.'})
            }
              );
        }   
        else
        {
          e.preventDefault();
          this.setState({message : ''})
        }
    }

    render() {
        return (
            <div id="update_user" className="m row ">
               
                      <div className="col-3">
                          <UserMainComponent/>
                          </div>

                 <div id="update-profile-component" className="col-5"> 
                
                            <center><div className="row g-2">
                            <h4 id="success" >{this.state.message}</h4>
                            </div></center>
                            
                            <center><div className="row g-3">
                            <h4 className="text-center">Update Profile</h4>
                            </div></center>
           
             
            
                   
               <center><form>
                                        
                        <div  id="admin-update-form" className="form-group">
                      
                            <label for="validationCustom01" class="form-label">Medical History</label>
                            <select class="form-select" name="medical_history" value={this.state.medical_history} onChange={this.onChange} aria-label="Default select example" id="validationCustom01" required>
                                <option selected disabled value="">Select</option>
                                <option value={none} onChange={this.onChange}>None</option>
                                <option value={heart_disease} onChange={this.onChange}>Heart disease</option>
                                <option value={respiratory_disease} onChange={this.onChange}>Respiratory disease</option>
                                </select>
                                <p id="errors">{this.state.medicalValidatedMessage}</p>
                               
                            </div>
                      

                    <div  id="admin-update-form" className="form-group">
                        <label>Name:</label>
                        <input  type="text" placeholder={this.state.name} name="name" className="form-control" value={this.state.name} onChange={this.onChange}  />
                        <p id="errors">{this.state.nameValidatedMessage}</p>
                    </div>
                        
                    <div  id="update-form" className="form-group">   
                            <label for="dob" class="form-label">Date of Birth</label>
                            <input type="date" id="dob" name="dob" className="form-control" value={this.state.dob} onChange={this.onChange} required/>
                            <p id="errors">{this.state.dobValidatedMessage}</p>
                    </div>

                    <div  id="update-form" className="form-group">   
                         <label for="gender" id="labelGender" class="form-label">Gender</label>  
                          <div role="group" name="gender" onChange={this.onChange}   aria-label="Basic radio toggle button group" required>
                        
                        <input type="radio" className="btn-check" name="gender" id="btnradio1" value={male} autocomplete="off"  onChange={this.onChange}/>
                        <label class="btn btn-outline-primary" for="btnradio1">Male</label>
                    
                        <input type="radio" className="btn-check" name="gender" id="btnradio2" value={female} autocomplete="off" onChange={this.onChange} />
                        <label class="btn btn-outline-primary" for="btnradio2">Female</label>
                       
                        <label class="btn btn-outline-primary" for="btnradio3">Other</label>
                        <input type="radio" className="btn-check" name="gender" id="btnradio3" value={other} autocomplete="off" onChange={this.onChange}/>
                    </div>


                    <div id="update-form" className="form-group">
                        <label> Email:</label>
                        <input placeholder="Email" name="email" className="form-control" value={this.state.email} onChange={this.onChange}/>
                        <p id="errors">{this.state.emailValidatedMessage}</p>
                    </div>

                    

                    <div  id="update-form" className="form-group">
                        <label>Address:</label>
                        <textarea rows="2" id="address" className="form-control" placeholder="Enter Address" cols="20" name="address" value={this.state.address} onChange={this.onChange} ></textarea>
                        <p id="errors">{this.state.addressValidatedMessage}</p>
                    </div>

                    <div id="update-form" className="form-group">
                            <label>Contact:</label>
                            <input type="text" placeholder="Contact" name="contact_no" className="form-control" value={this.state.contact_no} onChange={this.onChange}/>
                            <p id="errors">{this.state.contactValidatedMessage}</p>
                    </div>
                      
                    <div id="update-form" className="form-group">
                            <label for="aadharNumber" class="form-label">Aadhar number</label>
                            <input type="text" id="aadharNumber" placeholder="Enter aadhar number" name="aadharNumber" className="form-control" value={this.state.aadharNumber} onChange={this.onChange} required/>
                            <p id="errors">{this.state.aadharValidatedMessage}</p>
                    </div>


                    <div className="form-group">
                    <button className="btn btn-success" onClick={this.saveUser}>Update</button>
                    </div>
                   
                    </div>
               
                </form>
                </center>  
                </div>
               
                
            </div>
        );
    }

}

export default UpdateUserDetailsComponent;