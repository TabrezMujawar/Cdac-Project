import React from 'react';
import AppointmentService from '../../service/AppointmentService';
import UserMainComponent from '../user/UserMainComponent';

class UserAppointmentDetailsComponent extends React.Component
{
   
  constructor(props){
    super(props);
    this.state ={
        id: '',
        booking_date: '',
        booking_time: '',
        status: '',
        appId:null,
        message: null

       
    }
    this.getAppointmentDetails = this.getAppointmentDetails.bind(this);
    this.deleteAppointment=this.deleteAppointment.bind(this);
    this.bookNewAppointment=this.bookNewAppointment.bind(this);
  }

  componentDidMount()
  {
     
    this.getAppointmentDetails();
  }

  getAppointmentDetails()
  {
  
    let user=JSON.parse(sessionStorage.getItem("details"));
    let aid=sessionStorage.getItem("appointmentID");
    console.log("Appointment Id "+aid);
    if(aid===null)
    {
      console.log("in if")
          if(user.result.appointment!==null)
        {  
        AppointmentService.getAppointmentById(user.result.appointment.id)
        .then( res=> {
            let appointment = res.data;
            console.log(appointment);
            this.setState({
                id: appointment.id,
                booking_date: appointment.booking_date,
                booking_time: appointment.booking_time,
                status: "BOOKED",
            })
          
            })
            .catch(err=>{
              let appointmentDetails= document.getElementById("profile-component");
              appointmentDetails.innerHTML="<div className='col-8'><center><h2 className='h2'>No any Appointment booked</h2></center></div>";
            
            })
          }
         else
          {
          let appointmentDetails= document.getElementById("profile-component");
          appointmentDetails.innerHTML="<div className='col-8'><center><h2 className='h2'>No any Appointment booked</h2></center></div>";
         }
      }

      else
      {
        console.log("In else Appointment Id "+aid);
        let id=parseInt(aid);
        console.log("Number Appointment Id "+id);
        AppointmentService.getAppointmentById(id)
        .then( res=> {
            let appointment = res.data;
            console.log(appointment);
            this.setState({
                id: appointment.id,
                booking_date: appointment.booking_date,
                booking_time: appointment.booking_time,
                status: "BOOKED",
            })
          
            })
            .catch(err=>{
              let appointmentDetails= document.getElementById("profile-component");
              appointmentDetails.innerHTML="<div className='col-8'><center><h2 className='h2'>No any Appointment booked</h2></center></div>";
            
            })

      }
  }

  bookNewAppointment()
  {
      this.props.history.push("/book_appointment");
  }


  deleteAppointment(appID) {
    let details=JSON.parse(sessionStorage.getItem("details"));
    let user_id= details.result.id;
   AppointmentService.delAppointment(user_id,appID)
       .then(res => {
           this.setState({message : "Appointment cancelled"});
           sessionStorage.setItem("status","Absent");
           window.location.reload();
       })

}

   render()
   {
            return (
                       <div id="appointmentProfile" className="m row g-3">
                           
                           <div id="mainComponent" className="col-4">
                           <UserMainComponent/>
                          </div>
                            
                          <div id="profile-component" className="col-8">
                          <h2 className="row">Appointment Details</h2>
                          <h4 id="success">{this.state.message}</h4>
                          <div className="row">
                                  <div class="row g-3">
                                  <div class="col-6 col-md-4">
                                  <label style={{fontWeight:'bold'}}>Booking date  : </label>
                                   </div>
                                   <div class="col-6 col-md-4">
                                   <label>{this.state.booking_date}</label>     
                                   </div>
                                   </div>

                                  <div class="row g-3">
                                  <div class="col-6 col-md-4">
                                  <label style={{fontWeight:'bold'}}>Booking time  : </label>
                                   </div>
                                   <div class="col-6 col-md-4">
                                   <label>{this.state.booking_time}</label>     
                                   </div>
                                  </div>
                                 
                                  <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <lable style={{fontWeight:'bold'}}>STATUS :</lable>    
                                   </div>
                                   <div class="col-6 col-md-4" style={{backgroundColor:'lightgreen',width:'5rem'}} >
                                     <label >{this.state.status}</label>    
                                   </div>
                               </div>

                            

                               <div class="row g-3">
                                  <button className="btn btn-success" onClick={this.bookNewAppointment} style={{marginRight: '10px',width:'14rem'}}> Book new Appointment</button>
                                  <button  className="btn btn-danger" style={{width:'12rem'}} onClick={() => this.deleteAppointment(this.state.id)}> Cancel Appointment</button>
                               </div>

                               <p className="p row g-2" style={{color:'blue'}}>Note: To book new appointment cancel old appointment </p>
                            
                        </div>
                          </div>
                          </div>
                    

            )
           

   }

}

export default UserAppointmentDetailsComponent