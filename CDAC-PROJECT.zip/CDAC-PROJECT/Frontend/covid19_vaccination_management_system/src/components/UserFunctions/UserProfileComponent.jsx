import React from 'react';
import UserMainComponent from '../user/UserMainComponent';

class UserProfileComponent extends React.Component
{
   
  constructor(props){
    super(props);
    this.state ={
        medical_history: '',
        name: '',
        dob: '',
        gender: '',
        email: '',
        address: '',
        contact_no: '',
        aadharNumber: ''
       
    }
    this.getProfile = this.getProfile.bind(this);
  }

  componentDidMount()
  {
    this.getProfile();
  }


  getProfile()
  {
    let details=JSON.parse(sessionStorage.getItem("details"));
    let userId=details.result.id;
    // AdminService.getAdmin(adminID)
    fetch("http://localhost:6060/user/"+userId)
    .then(async (res)=> {
        console.log("In User");
        let user =  await res.json();
        console.log(user);
        this.setState({
        medical_history: user.result.medical_history,
        name: user.result.name,
        dob: user.result.dob,
        gender: user.result.gender,
        email: user.result.email,
        address: user.result.address,
        contact_no: user.result.contact_no,
        aadharNumber: user.result.aadharNumber
        })
    })
  }

   render()
   {
            return (
                       <div id="userProfile" className="m row g-3">
                           
                           <div id="mainComponent" className="col-3">
                           <UserMainComponent/>
                          </div>
                          
                          <div id="profile-component" className="col-8">
                          <div className="row">
                                  <div class="row g-3">
                                  <div class="col-6 col-md-4">
                                  <label style={{fontWeight:'bold'}}>Medical history  : </label>
                                   </div>
                                   <div class="col-6 col-md-4">
                                   <label>{this.state.medical_history}</label>     
                                   </div>
                                   </div>

                                  <div class="row g-3">
                                  <div class="col-6 col-md-4">
                                  <label style={{fontWeight:'bold'}}>Name  : </label>
                                   </div>
                                   <div class="col-6 col-md-4">
                                   <label>{this.state.name}</label>     
                                   </div>
                                  </div>
                                 
                                  <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <lable style={{fontWeight:'bold'}}>Date of birth :</lable>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.dob}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <lable style={{fontWeight:'bold'}}>Gender :</lable>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.gender}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <lable style={{fontWeight:'bold'}}>Email :</lable>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.email}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Address :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.address}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Contact :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.contact_no}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Aadhar Number :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.aadharNumber}</label>    
                                   </div>
                               </div>
                            
                        </div>
                          </div>
                          </div>
                    

            )
           

   }

}

export default UserProfileComponent