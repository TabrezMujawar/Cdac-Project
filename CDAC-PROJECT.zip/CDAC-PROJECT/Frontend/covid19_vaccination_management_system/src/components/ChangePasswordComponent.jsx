import React, { Component } from 'react'
import ChangePasswordService from '../service/ChangePasswordService';
import AdminMainComponent from './admin/AdminMainComponent';
import UserMainComponent from './user/UserMainComponent';
import StaffMainComponent from './staff/StaffMainComponent';


class ChangePasswordComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            role: '',
            email: '',
            oldPassword: '',
            newPassword: ''
           
        }
        this.changePassword = this.changePassword.bind(this);
    }

    componentDidMount()
    {
        this.checkmainComp();
    }

        checkmainComp()
        {
            let r=sessionStorage.getItem("role");
            this.setState({role:r})
                if(r==="ADMIN")
                {
                    document.getElementById("m-comp-user").remove();
                    document.getElementById("m-comp-staff").remove();
                }
               else if(r==="USER")
                {

                    document.getElementById("m-comp-admin").remove();
                    document.getElementById("m-comp-staff").remove();
                }
                else if(r==="STAFF")
                {
                    document.getElementById("m-comp-admin").remove();
                    document.getElementById("m-comp-user").remove();
                }
                else
                {
                   document.getElementById("m-comp-admin").remove();
                   document.getElementById("m-comp-user").remove();
                   document.getElementById("m-comp-staff").remove();
                }

        } 


         validEmail()
         { 
          if(this.state.email==='' || !this.state.email.includes("@") || !this.state.email.endsWith(".com"))
          {
            this.setState({emailValidatedMessage:"Please enter valid email"});
            
            return false;
          }
          else
          {
            this.setState({emailValidatedMessage:""});
         
            return true;
          }
         }

         validOldPassword()
         {
            if(this.state.oldPassword==='' || !(this.state.oldPassword.length<=10 && this.state.oldPassword.length>=5) )
            {
              this.setState({oldPasswordValidatedMessage:"Password must contain at least 5 character and less than 10 characters"});
              return false;
            }
            this.setState({oldPasswordValidatedMessage:""});
            return true;
         }

         validNewPassword()
         {
            if(this.state.newPassword==='' || !(this.state.newPassword.length<=10 && this.state.newPassword.length>=5) )
            {
              this.setState({newPasswordValidatedMessage:"Password must contain at least 5 character and less than 10 characters"});
              return false;
            }
            this.setState({newPasswordValidatedMessage:""});
            return true;
         }


        validAdmin()
         {
             let isValid=true;
             if(!this.validEmail())
             {
               isValid=false;
             }         
             if(!this.validOldPassword())
             {
               isValid=false;
             } 
             if(!this.validNewPassword())
             {
               isValid=false;
             } 
            return isValid;
        }
         
     
    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

        changePassword = (e) => {
        if(this.validAdmin())
        {
        e.preventDefault();

        let details = {role: this.state.role, email: this.state.email, oldPassword : this.state.oldPassword, newPassword: this.state.newPassword};
        ChangePasswordService.changePassword(details)
        .then(res => {
                document.getElementById("message").style.color="green";
                this.setState({message : 'Password changed successfully.'});
            })
            .catch(err =>{
              document.getElementById("message").style.color="red";
              this.setState({message : 'Invalid email or old password'});
              console.log(err);
            }
              );
        }   
    }

    render() {
        return (
            <div id="change-password" style={{marginTop:"2rem"}} className="row ">
               
                    <div id="m-comp-admin" className="col-4">
                        <AdminMainComponent/>
                          </div>
                    <div id="m-comp-user" className="col-4">
                        <UserMainComponent/>
                          </div>
                    <div id="m-comp-staff" className="col-4">
                        <StaffMainComponent/>
                          </div>
                 <div id="update-profile-component" className="col-4"> 
                 <center><div className="row g-2">
                    <h4 id="message" >{this.state.message}</h4>
                      </div></center>
                      <center><div className="row g-3">
                    <h4 className="text-center">Change password</h4>
                </div></center>
         
               <center> <form>

                    <div className="form-group">
                        <label> Email:</label>
                        <input placeholder="Enter email" name="email" className="form-control" value={this.state.email} onChange={this.onChange}/>
                        <p id="errors">{this.state.emailValidatedMessage}</p>
                    </div>

                    <div  className="form-group">
                        <label for="oldPassword" class="form-label">Old Password</label>
                        <input type="password" id="oldPassword" placeholder="Enter old password" name="oldPassword" className="form-control" value={this.state.oldPassword} onChange={this.onChange} required/>
                        <p id="errors">{this.state.oldPasswordValidatedMessage}</p>
                    </div>

                    <div  className="form-group">
                    <label for="newPassword" class="form-label">New Password</label>
                        <input type="password" id="oldPassword" placeholder="Enter new password" name="newPassword" className="form-control" value={this.state.newPassword} onChange={this.onChange} required/>
                        <p id="errors">{this.state.newPasswordValidatedMessage}</p>
                    </div>
                    <div className="form-group">
                    <button className="btn btn-primary" onClick={this.changePassword}>Submit</button>
                    </div>
                   
                 
               
                </form></center>  
              
                </div>
               
                
            </div>
        );
    }
}

export default ChangePasswordComponent;