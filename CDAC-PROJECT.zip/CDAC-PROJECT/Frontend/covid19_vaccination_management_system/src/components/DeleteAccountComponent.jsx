
import UserService from "../service/UserService";
import React from 'react';

class DeleteAccountComponent extends React.Component
{
    render()
    {
           let details=JSON.parse(sessionStorage.getItem("details"));

           UserService.deleteUser(details.result.id)
                .then(res=>
                    {
                        this.props.history.push("/");
                    }
                )
       
          return(null);    
     }

    
}

export default DeleteAccountComponent;