import React, { Component } from 'react'
import { Redirect } from 'react-router';
import {admin,user,staff} from "../constants/roles";
import ForgetPasswordService from '../service/ForgetPasswordService';


class ForgetPasswordComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            role: '',
            email: '',
            newPassword: ''
           
        }
        this.changePass = this.changePass.bind(this);
    }

          

    validRole()
    {
       if(this.state.role==='')
       {
         this.setState({validateRolemessage:"Please select role"});
         return false
       }
       else  
       { 
       this.setState({validateRolemessage:""});
        return true;
       }
    }


    validEmail()
    { 
     if(this.state.email==='' || !this.state.email.includes("@") || !this.state.email.endsWith(".com"))
     {
       this.setState({emailValidatedMessage:"Please enter valid email"});
       
       return false;
     }
     
       this.setState({emailValidatedMessage:""});
       return true;
     
    }

       

    validNewPassword()
    {
    if(this.state.newPassword==='' || !(this.state.newPassword.length<=10 && this.state.newPassword.length>=5) )
    {
        this.setState({newPasswordValidatedMessage:"Password must contain at least 5 character and less than 10 characters"});
        return false;
    }
    this.setState({newPasswordValidatedMessage:""});
    return true;
    }


    
    validDetails()
   {
       let isValid=true;
      
       if(!this.validEmail())
       {
         isValid=false;
       }
       if(!this.validRole())
       {
           isValid=false;
       } 
       if(!this.validNewPassword())
       {
         isValid=false;
       }             
   
      return isValid;
  }    
         


     
        onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

        
        
        changePass = (e) => {

            if(this.validDetails())
            {
                    e.preventDefault();

                    let info= {role: this.state.role, email: this.state.email, newPassword: this.state.newPassword};
                     console.log("Data : ",info);
                    ForgetPasswordService.resetPassword(info)
                    .then(res => {
                             console.log("In then",res.data)
                            document.getElementById("message").style.color="green";
                            this.setState({message : ''});
                            this.setState({message : 'Password changed successfully........you are automatically redirecting to login page'});
                            setTimeout(function(){
                                window.location.href = 'http://localhost:3000/login';
                             }, 5000)
                            
                        })
                        .catch(err =>{
                        document.getElementById("message").style.color="red";
                        this.setState({message : ''});
                        this.setState({message : 'Password updation failed'});
                        console.log(err);
                        }
                        );
                    }
    }

    render() {
        return (
            <div id="forget-password" className="m row ">
               
                 <div id="update-profile-component" className="col-4"> 
                 <center><div className="row g-2">
                    <h4 id="message" >{this.state.message}</h4>
                      </div></center>
                      <center><div className="row g-3">
                    <h4 className="text-center">Reset password</h4>
                </div></center>
         
               <center> <form>

                    
               <center>       <div class="col-md-3">
                                <label for="role" class="form-label">Role</label>
                                <select class="form-select" name="role" onChange={this.onChange} aria-label="Default select example" id="role" required>
                                    <option selected disabled value="">Select role</option>
                                    <option value={admin} onChange={this.onChange}>Admin</option>
                                    <option value={user} onChange={this.onChange}>User</option>
                                    <option value={staff} onChange={this.onChange}>Staff</option>
                                    </select>
                                    <p id="errors">{this.state.validateRolemessage}</p>
                                    </div></center>

                                    <div  className="form-group">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" placeholder="Enter email" class="form-control" id="email" name="email" value={this.state.email} onChange={this.onChange} aria-describedby="emailHelp" required/>
                                    <p id="errors">{this.state.emailValidatedMessage}</p>
                                    </div>
                                
                   
                                    <div  className="form-group">
                                    <label for="newPassword" class="form-label">New Password</label>
                                        <input type="password" id="newPassword" placeholder="Enter new password" name="newPassword" className="form-control" value={this.state.newPassword} onChange={this.onChange} required/>
                                        <p id="errors">{this.state.newPasswordValidatedMessage}</p>
                                    </div>

                                    <div className="form-group">
                                    <button className="btn btn-primary" onClick={this.changePass}>Submit</button>
                                    </div>
                   
                 
               
                </form></center>  
              
                </div>
               
                
            </div>
        );
    }
}

export default ForgetPasswordComponent;