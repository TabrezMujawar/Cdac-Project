import React from 'react';

class ServiceComponent extends React.Component
{
   render()
   {
            return (
                       <div id="services" className="row">
                        <div class="jumbotron jumbotron-fluid">
                           <div class="container">
                              <h1 class="display-4" style={{fontWeight:'inherit',marginTop:"4rem"}}>Services</h1>
                              <p class="lead" style={{marginTop:"4rem",marginBottom:"4rem"}}>
                              A year after the WHO declared COVID-19 a pandemic.It is to relief that now we are having
                              a number of vaccines in the market of India and at the same time there are many vulnerable
                              countries which are unable to administer a single dose of vaccine.We at "COVID-19 Vaccination
                              Management System" are trying our level best to be the part of government of India's initiative 
                              of vaccine for all.For this to happen we need to have a well mechanised,disciplined and easy to
                              access digital network,which can be helpful for all.We are providing a digital framework which
                              will enable each and every person to get the vaccine and there doses on time and at the same
                              time the framework will help to inculcate people from "far to reach areas" so that they won't
                              get left alone.The system will also help local bodies, and at the center to track the record 
                              of the areas,towns and cities in India to get the status of the number of people being vaccinated.
                                </p>
                           </div>
                        </div>
                           
                       </div>

            )
           

   }

}

export default ServiceComponent;