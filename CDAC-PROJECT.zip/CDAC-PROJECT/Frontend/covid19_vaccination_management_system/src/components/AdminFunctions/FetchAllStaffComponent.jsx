import React, { Component } from 'react'
import StaffService from "../../service/StaffService";
import AdminMainComponent from '../admin/AdminMainComponent';

class FetchAllStaffComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            staff: [],
            message: null
        }
        this.deleteStaff = this.deleteStaff.bind(this);
        this.editStaff = this.editStaff.bind(this);
        this.addStaff = this.addStaff.bind(this);
        this.reloadStaffList = this.reloadStaffList.bind(this);
    }

    componentDidMount() {
        this.reloadStaffList();
    }


    
    reloadStaffList() {
        StaffService.getAllStaff()
            .then((res) => {
                console.log("In get all staff")
                console.log(res.data);
                this.setState({
                    staff: res.data.result,
                    adminId:JSON.parse(sessionStorage.getItem("details")).result.id
                })
                console.log("adminId : "+this.state.adminId);
                console.log(this.state.staff);
            });
            // UserService.getUsers().then(resp => {
            //     this.setState({ users: resp.data });
            //     console.log(this.state.users);
            // })
    }
  
    deleteStaff(staffId) {
        let details=JSON.parse(sessionStorage.getItem("details"));
        let admin_id= parseInt(details.result.id);
       console.log(admin_id);
        StaffService.deleteStaff(admin_id,staffId)
           .then(res => {
               this.setState({message : 'Staff deleted successfully.'});
               this.setState({staff: this.state.staff.filter(stf => stf.id !== staffId)});
           })

    }

    editStaff(id) {
        window.localStorage.setItem("staffId",id);
        this.props.history.push('/staff_update');
    }

    addStaff() {
        window.localStorage.removeItem("staffId");
        this.props.history.push('/staff_add');
    }

    render() {
        return (
            <div class="m row g-2" style={{marginTop:"4rem"}}>
                <div className="col-4">
                  <AdminMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                      <div className="row g-2">
                         <h4 id="success">{this.state.message}</h4>
                      </div>
                <h2 className="text-center">Staff Details</h2>
                <button className="btn btn-success" style={{width:'100px'}} onClick={() => this.addStaff()}> Add Staff</button>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Contact number</th>
                            <th>Lab number</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.staff.map(
                         stf =>
                                    <tr key={stf.id}>
                                        <td>{stf.id}</td>
                                        <td>{stf.name}</td>
                                        <td>{stf.email}</td>
                                        <td>{stf.address}</td>
                                        <td>{stf.contact_no}</td>
                                        <td>{stf.lab_no}</td>
                                        <td>
                                           <button className="btn btn-danger" onClick={() => this.deleteStaff(stf.id)}> Delete</button>
                                        </td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>
             </div>
            </div>
        );
    }

}

export default FetchAllStaffComponent;