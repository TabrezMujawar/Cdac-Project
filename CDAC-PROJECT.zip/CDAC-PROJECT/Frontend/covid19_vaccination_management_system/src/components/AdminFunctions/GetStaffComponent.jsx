import React from 'react';
import StaffService from '../../service/StaffService';
import AdminMainComponent from '../admin/AdminMainComponent';

class GetStaffComponent extends React.Component
{
   
  constructor(props){
    super(props)
    this.state ={
        staff: '',
        staffId: '',
        message: null
    }
    this.getStaff = this.getStaff.bind(this);
    this.deleteStaff = this.deleteStaff.bind(this);
  }

  getStaff=(sid)=>{
    
    console.log(sid)
    if(sid!=="")
     {     
       StaffService.getStaffById(sid)
          .then((res)=> {
            console.log(res.data.result);
              
              this.setState({
                  staff:res.data.result,
                  message:"Staff fetched successfully"
              }) 
                document.getElementById('search-staff').style.visibility = "visible";    
                document.getElementById('error').style.color="green";
          })
          .catch((err)=>{
            document.getElementById('error').style.color="red";
            this.setState({message:"Invalid staff id"});
          })
      }
     else
     {
             document.getElementById('error').style.color="red";
              this.setState({message:"Please enter valid id"});

     } 
    
    
  }

  deleteStaff(sid) {
    StaffService.deleteStaff(sid)
       .then(res => {
        
           this.setState({message : 'Staff deleted successfully.'});
       })
         this.props.history.push("/get_staff");
         document.getElementById('search-staff').style.visibility = "hidden";
         document.getElementById('error').style.color="green";  
    }

       onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });

   render()
   {
            return (
                <div class="m row g-2">
                <div className="col-4">
                  <AdminMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                      <div className="row g-2">
                         <h4 id="error">{this.state.message}</h4>
                      </div>
                 <div className="row g-2">
                      <div class="col-md-3">  
                      <label for="staffID" class="form-label">Enter Staff Id</label>
                      </div>
                      <div class="col-md-4">
                     <input type="number" class="form-control" id="staffId" name="staffId" value={this.state.staffId} onChange={this.onChange}/>
                     </div>
                     <div className="col-md-4">
                     <button className="btn btn-success"  style={{width:'100px'}} onClick={() => this.getStaff(this.state.staffId)}>Search</button>
                     </div>
                </div>
             
                <table className="table table-striped" id="search-staff">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Contact number</th>
                            <th>Lab number</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                   
                                    <tr key={this.state.staff.id}>
                                        <td>{this.state.staff.id}</td>
                                        <td>{this.state.staff.name}</td>
                                        <td>{this.state.staff.email}</td>
                                        <td>{this.state.staff.address}</td>
                                        <td>{this.state.staff.contact_no}</td>
                                        <td>{this.state.staff.lab_no}</td>
                                        <td>
                                           <button className="btn btn-danger" onClick={() => this.deleteStaff(this.state.staff.id)}> Delete</button>
                                        </td>
                                    </tr>
                            
                        }
                    </tbody>
                </table>
             </div>
            </div>
                    

            )
           

   }
  
}

export default GetStaffComponent;