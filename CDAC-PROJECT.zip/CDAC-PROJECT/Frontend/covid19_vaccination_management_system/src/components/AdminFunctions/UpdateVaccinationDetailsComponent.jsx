import React, { Component } from 'react'
import {bharat_biotech,serum_institue,zydus_cadia,panacea_biotech} from "../../constants/pharma_companies.js";
import VaccinatedPersonService from '../../service/VaccinatedPersonService';
import AdminMainComponent from '../admin/AdminMainComponent';

class UpdateVaccinationDetailsComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
             id: '',
            aadhar_number: '',
            pharmaceutical_company: '',
           
           
        }
        this.updateVc= this.updateVc.bind(this);
        this.loadVcc = this.loadVcc.bind(this);
    }


    validAadharNumber()
    { 
      if(this.state.aadhar_number==='')
    {
      this.setState({aadharValidatedMessage:"Please enter valid aadhar number"});
      return false;
    }
    this.setState({aadharValidatedMessage:""});
    return true;
   }
  
   validPharmaCompany()
   {
    if(this.state.pharmaceutical_company==="")
    {
      this.setState({pharmaValidatedMessage:"Please select pharma company"});
      return false;
    }
    this.setState({pharmaValidatedMessage:""});
    return true;
   }
  
   validVccPerson()
        {
         let isValid=true;
          if(!this.validAadharNumber())
          {
          isValid=false;
          }
          if(!this.validPharmaCompany())
          {
          isValid=false;
           }
          return isValid;
           
        }
   
   componentDidMount() {
    this.loadVcc();
    }
     


  loadVcc()
   {
    
    let vccId=JSON.parse(sessionStorage.getItem("vccId"))
    console.log("VccId " +vccId);
      fetch("http://localhost:6060/vd/"+vccId)
          .then(async (res)=> {
              let vcc_person = await res.json();
              console.log(vcc_person.id);
              this.setState({
              aadhar_number: vcc_person.aadhar_number,
              pharmaceutical_company: vcc_person.pharmaceutical_company
             })
      
            })      
        
        }

    

    updateVc = (e) => {
        let vccId=JSON.parse(sessionStorage.getItem("vccId"))
        if(this.validVccPerson())
        {
        e.preventDefault();
        let vcc = {id:vccId,aadhar_number: this.state.aadhar_number, pharmaceutical_company: this.state.pharmaceutical_company};
        VaccinatedPersonService.updateVccPersonById(vccId,vcc)
            .then(res => {
                document.getElementById("success").style.color="green";
                this.setState({message : 'Vaccinated person details updated successfully.'});
                this.props.history.push('/update_vaccination_person');
            })
            .catch(err =>{
                document.getElementById("success").style.color="red";
                this.setState({message : 'Vaccinated person details updation failed.'});
                console.log(err);
            }
              );
        }
         
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {
        return (
            <div id="m update_vcc" className="row ">
               
                      <div className="col-3">
                          <AdminMainComponent/>
                          </div>
                 <div id="update-profile-component" className="col-5"> 
                 <center><div className="row g-2">
                 <h4 id="success" >{this.state.message}</h4>
                  </div></center>
                  <center><div className="row g-3">
                <h4 className="text-center">Update Vaccination Details</h4>
                </div></center>
           
                <center><form>
                    <div className="form-group">
                       <label for="aadhar_number" class="form-label">Aadhar Number:</label>
                       <input type="text" id="aadhar_number" name="aadhar_number" value={this.state.aadhar_number} className="form-control" onChange={this.onChange} required />
                       <p id="errors">{this.state.aadharValidatedMessage}</p>
                    </div>

                <div className="form-group">
                    <label for="pharmaceutical_company" class="form-label">Pharmaceutical Company</label>
                    <select class="form-select" name="pharmaceutical_company" onChange={this.onChange} aria-label="Default select example" id="pharmaceutical_company"  required>
                    <option selected disabled value="">Select</option>
                    <option  value={bharat_biotech} onChange={this.onChange}>BHARAT_BIOTECH</option>
                    <option value={serum_institue} onChange={this.onChange}>SERUM_INSTITUTE</option>
                    <option value={zydus_cadia} onChange={this.onChange}>ZYDUS_CADILA</option>
                    <option value={panacea_biotech} onChange={this.onChange}>PANACEA_BIOTECH</option> 
                    </select>
                    <p id="errors">{this.state.pharmaValidatedMessage}</p>
                </div> 

                 <div lassName="col-md-4">
                 <button className="btn btn-success" onClick={this.updateVc}>Update</button>
                 </div>
                   
                </form></center>  
              
                </div>
               
                
            </div>
        );
    }
}

export default UpdateVaccinationDetailsComponent;