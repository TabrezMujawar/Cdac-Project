import React from 'react'
import VaccinatedPersonService from '../../service/VaccinatedPersonService';
import AdminMainComponent from '../admin/AdminMainComponent';

class FetchAllVaccinatedPersonsComponent extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            vccPersons:[],
            message: null
        }
        this.deleteVccPerson=this.deleteVccPerson.bind(this);
        this.updateVccPerson=this.updateVccPerson.bind(this);
        this.reloadVccPersonsList = this.reloadVccPersonsList.bind(this);
    }

    componentDidMount() {
        this.reloadVccPersonsList();
    }
      
    showDetails()
    {
        this.props.history.push("/show_details")
    }


    deleteVccPerson(vccId) {
        VaccinatedPersonService.deleteVccPerson(vccId)
           .then(res => {
               this.setState({message : 'Vaccinated person deleted successfully.'});
               this.setState({vccPersons: this.state.vccPersons.filter(vcc => vcc.id !== vccId)});
           })

    }

    updateVccPerson(id) {

        sessionStorage.setItem("vccId", id);
        this.props.history.push("/update_vaccination_person");
        
    }

   

    reloadVccPersonsList() {
          VaccinatedPersonService.getallVccPerson()
            .then(res => {
                console.log("In get all vaccinated persons")
                console.log(res.data);
                this.setState({vccPersons: res.data})
                console.log("Vaccinated persons : "+this.state.vccPersons);
            });
           
    }
 
  
    render()
     {
        return (
            <div class="m row g-2">
                <div className="col-4">
                  <AdminMainComponent/>
                  </div>

                  <div id="list" className="col-9">
                  <div className="row g-2">
                         <h4 id="success">{this.state.message}</h4>
                      </div>
                <h2 className="text-center">All Vaccinated Persons Details</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Aadhar Number</th>
                            <th>Pharmaceutical Company</th>
                            </tr>                       
                    </thead>
                    
                    <tbody>
                        {  
                            this.state.vccPersons.map(
                                vcc =>
                                    <tr key={vcc.id}>
                                        <td id="attr">{vcc.id}</td>
                                        <td>{vcc.aadhar_number}</td>
                                        <td>{vcc.pharmaceutical_company}</td>
                                        <td >
                                            <button className="btn btn-danger" onClick={() => this.deleteVccPerson(vcc.id)}> Delete</button>
                                            <button className="btn btn-success" onClick={() => this.updateVccPerson(vcc.id)} style={{marginLeft: '10px',marginRight: '10px'}}> Update</button>
                                            <button className="btn btn-primary" onClick={() => this.showDetails()}> View Details</button>
                                        </td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>
             </div>
            </div>
        )
    }

}

export default FetchAllVaccinatedPersonsComponent;