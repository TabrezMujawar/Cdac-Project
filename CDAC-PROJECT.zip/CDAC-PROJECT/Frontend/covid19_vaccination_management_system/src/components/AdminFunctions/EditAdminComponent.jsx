import { type } from 'jquery';
import React, { Component } from 'react'
import AdminService from "../../service/AdminService";
import AdminMainComponent from '../admin/AdminMainComponent';

class EditAdminComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            id: '',
            name: '',
            email: '',
            address: '',
            contact_no: ''
           
        }
        this.saveAdmin = this.saveAdmin.bind(this);
        this.loadAdmin = this.loadAdmin.bind(this);
    }

    

    validName()
         { 
          if(this.state.name==='')
          {
            this.setState({nameValidatedMessage:"Please enter valid name"});
            
            return false;
          }
          else
          {
            this.setState({nameValidatedMessage:""});
           
            return true;
          }
         }

         validEmail()
         { 
          if(this.state.email==='' || !this.state.email.includes("@") || !this.state.email.endsWith(".com"))
          {
            this.setState({emailValidatedMessage:"Please enter valid email"});
            
            return false;
          }
          else
          {
            this.setState({emailValidatedMessage:""});
         
            return true;
          }
         }

         validAddress()
         {
          if(this.state.address==='')
          {
            this.setState({addressValidatedMessage:"Please enter valid address"});
            return false;
          }
          this.setState({addressValidatedMessage:""});
          return true;
         }

         validContact()
         {
           if(this.state.contact_no==='' ||  !this.state.contact_no.length===10)
          {
            this.setState({contactValidatedMessage:"Please enter valid mobile number"});
            return false;
          }
          this.setState({contactValidatedMessage:""});
          return true;
         }

        validAdmin()
         {
             let isValid=true;
             if(!this.validName())
             {
               isValid=false;
             }   
             if(!this.validEmail())
             {
               isValid=false;
             }         
             if(!this.validAddress())
             {
               isValid=false;
             } 
             if(!this.validContact())
             {
               isValid=false;
             } 
            return isValid;
        }
         
        componentDidMount() {
            this.loadAdmin();
        }

         loadAdmin() {
      let details=JSON.parse(sessionStorage.getItem("details"));
      console.log("Id : "+details.result.id);
      let adminID=details.result.id;
     // AdminService.getAdmin(adminID)
          fetch("http://localhost:6060/admin/"+adminID)
            .then(async (res)=> {
                console.log("In Admin");
                 let admin =  await res.json();
                console.log("Admin : "+admin.result);
                console.log(admin.result.id);
                this.setState({
                id: admin.result.id,
                name: admin.result.name,
                email: admin.result.email,
                address: admin.result.address,
                contact_no: admin.result.contact_no
                })
            })
            
           
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    saveAdmin = (e) => {
        if(this.validAdmin())
        {
        e.preventDefault();
        let admin = {id: this.state.id, name: this.state.name, email: this.state.email, address: this.state.address, contact_no: this.state.contact_no};
        AdminService.editAdmin(admin)
            .then(res => {
                document.getElementById("message").style.color="green";
                this.setState({message : 'Admin updated successfully.'});
                this.props.history.push('/admin_update');
            })
            .catch(err =>{
              document.getElementById("message").style.color="red";
              this.setState({message : 'Admin updation failed.'});
              console.log(err);
            }
              );
        }   
        else{
          e.preventDefault();
          this.setState({message : ''})
        }
    }

    render() {
        return (
            <div id="update_admin" style={{marginTop:"2rem"}} className="row ">
               
                      <div className="col-3">
                          <AdminMainComponent/>
                          </div>
                 <div id="update-profile-component" className="col-5"> 
                 <center><div className="row g-2">
                 <h4 id="message" >{this.state.message}</h4>
                  </div></center>
                  <center><div className="row g-3">
                <h4 className="text-center">Update Profile</h4>
                </div></center>
           
             
            
                   
               <center> <form>

                    <div  id="admin-update-form" className="form-group">
                        <label>Admin Name:</label>
                        <input  type="text" placeholder={this.state.name} name="name" className="form-control" defaultValue={this.state.name} onChange={this.onChange}  />
                        <p id="errors">{this.state.nameValidatedMessage}</p>
                    </div>

                    <div id="admin-update-form" className="form-group">
                        <label> Email:</label>
                        <input placeholder="Email" name="email" className="form-control" value={this.state.email} onChange={this.onChange}/>
                        <p id="errors">{this.state.emailValidatedMessage}</p>
                    </div>

                    <div  id="admin-update-form" className="form-group">
                        <label>Address:</label>
                        <textarea rows="2" id="address" className="form-control" placeholder="Enter Address" cols="20" name="address" value={this.state.address} onChange={this.onChange} ></textarea>
                        <p id="errors">{this.state.addressValidatedMessage}</p>
                    </div>

                    <div id="admin-update-form" className="form-group">
                        <label>Contact:</label>
                        <input type="text" placeholder="Contact" name="contact_no" className="form-control" value={this.state.contact_no} onChange={this.onChange}/>
                        <p id="errors">{this.state.contactValidatedMessage}</p>
                    </div>
                    <div className="form-group">
                    <button className="btn btn-success" onClick={this.saveAdmin}>Update</button>
                    </div>
                   
                 
               
                </form></center>  
              
                </div>
               
                
            </div>
        );
    }
}

export default EditAdminComponent;