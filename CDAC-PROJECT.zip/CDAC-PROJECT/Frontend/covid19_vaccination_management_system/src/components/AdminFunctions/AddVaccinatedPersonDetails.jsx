import React from 'react';
import {bharat_biotech,serum_institue,zydus_cadia,panacea_biotech} from "../../constants/pharma_companies.js";
import VaccinatedPersonService from '../../service/VaccinatedPersonService';
import AdminMainComponent from '../admin/AdminMainComponent';

class AddVaccinatedPersonDetails extends React.Component
{
   
  constructor(props){
    super(props)
    this.state ={
        aadhar_number: '',
        pharmaceutical_company: '',
        message: null
    }
    this.addVcperson = this.addVcperson.bind(this);
  }

  validAadharNumber()
  { 
    if(this.state.aadhar_number==='')
  {
    this.setState({aadharValidatedMessage:"Please enter valid aadhar number"});
    return false;
  }
  this.setState({aadharValidatedMessage:""});
  return true;
 }

 validPharmaCompany()
 {
  if(this.state.pharmaceutical_company==="")
  {
    this.setState({pharmaValidatedMessage:"Please select pharma company"});
    return false;
  }
  this.setState({pharmaValidatedMessage:""});
  return true;
 }

 validVccPerson()
      {
       let isValid=true;
        if(!this.validAadharNumber())
        {
        isValid=false;
        }
        if(!this.validPharmaCompany())
        {
        isValid=false;
         }
        return isValid;
         
      }

 addVcperson=(e)=>{

    if(this.validVccPerson())
    {
       e.preventDefault();
    let vaccinated_person={aadhar_number:this.state.aadhar_number,pharmaceutical_company:this.state.pharmaceutical_company}
    console.log(vaccinated_person);
      VaccinatedPersonService.addVccPerson(vaccinated_person)
          .then(res=> {
            console.log("Vaccination details : "+res.data.result); 
            document.getElementById("success").style.color="green";
              this.setState({
                  vaccinatedPerson:res.data,
                  message:"Vaccinated person added successfully"
              })
          })
          .catch( err=> {
            document.getElementById("success").style.color="red";
              this.setState({
                message:"Registration failed due to incorrect inputs"
                      })
                 }
          )          
     }     
    
  }

       onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });

   render()
   {
       
            return (
                <div class="m row g-2">
                   <div className="col-4">
                  <AdminMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                      <div className="row g-2">
                         <h4 id="success">{this.state.message}</h4>
                      </div>
                      <h2 className="h2">Add Vaccinated Person</h2>
            <center><form>
                    <div className="form-group">
                       <label for="aadhar_number" class="form-label">Aadhar Number:</label>
                       <input type="text" id="aadhar_number" name="aadhar_number" value={this.state.aadhar_number} className="form-control" onChange={this.onChange} required />
                       <p id="errors">{this.state.aadharValidatedMessage}</p>
                    </div>

                <div className="form-group">
                    <label for="pharmaceutical_company" class="form-label">Pharmaceutical Company</label>
                    <select class="form-select" name="pharmaceutical_company" onChange={this.onChange} aria-label="Default select example" id="pharmaceutical_company"  required>
                    <option selected disabled value="">Select</option>
                    <option  value={bharat_biotech} onChange={this.onChange}>BHARAT_BIOTECH</option>
                    <option value={serum_institue} onChange={this.onChange}>SERUM_INSTITUTE</option>
                    <option value={zydus_cadia} onChange={this.onChange}>ZYDUS_CADILA</option>
                    <option value={panacea_biotech} onChange={this.onChange}>PANACEA_BIOTECH</option> 
                    </select>
                    <p id="errors">{this.state.pharmaValidatedMessage}</p>
                </div> 
            
                <div className="col-md-4">
                     <button className="btn btn-success" style={{width:'100px'}} onClick={this.addVcperson}>Register</button>
                     </div>
             </form></center>
             </div>
            </div>
                    

            )
           

   }
  
}

export default AddVaccinatedPersonDetails;