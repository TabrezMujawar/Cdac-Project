import React from 'react';
import UserService from '../../service/UserService';
import AdminMainComponent from '../admin/AdminMainComponent';

class GetVaccinatedPersonDetails extends React.Component
{
   
  constructor(props){
    super(props)
    this.state ={
        user: '',
        aadhar: '',
        message: null
    }
    this.getUser = this.getUser.bind(this);
  }

  getUser=(aadhar)=>{
    
    console.log(aadhar)
    if(aadhar!=="")
     {     
     UserService.fetchUserByAadharNumber(aadhar)
          .then((res)=> {
            console.log(res.data.result);
              
              this.setState({
                  user:res.data.result,
                  message:"Vaccinated user details fetched successfully"
              }) 
                document.getElementById('search-user').style.visibility = "visible";    
                document.getElementById('error').style.color="green";
          })
          .catch((err)=>{
            document.getElementById('error').style.color="red";
            this.setState({message:"Invalid aadhar number"});
            document.getElementById('search-user').style.visibility = "hidden"; 
          })
      }
     else
     {
             document.getElementById('error').style.color="red";
             this.setState({message:"Please enter valid aadhar number"});
             document.getElementById('search-user').style.visibility = "hidden"; 

     } 
    
    
  }
/*
  deleteStaff(uid) {
    StaffService.deleteStaff(sid)
       .then(res => {
        
           this.setState({message : 'Staff deleted successfully.'});
       })
         this.props.history.push("/get_staff");
         document.getElementById('search-staff').style.visibility = "hidden";
         document.getElementById('error').style.color="green";  
    }
*/
       onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });

   render()
   {
            return (
                <div class="m row g-2">
                <div className="col-4">
                  <AdminMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                      <div className="row g-2">
                         <h4 id="error">{this.state.message}</h4>
                      </div>
                      <div className="row g-4">
                       <center><p id="note" style={{color:"blue"}}>Note : Please enter vaccinated person aadhar number to view details</p></center>
                     </div>
                 <div className="row g-6">
                   
                      <div class="col-md-3">  
                      <label for="aadhar">Enter aadhar number</label>
                      </div>
                      <div class="col-md-4">
                     <input type="text" class="form-control" id="aadhar" name="aadhar" value={this.state.aadhar} onChange={this.onChange}/>
                     </div>
                     <div className="col-md-3">
                     <button className="btn btn-primary"  style={{width:'100px'}} onClick={() => this.getUser(this.state.aadhar)}>Search</button>
                     </div>
                     
                </div>
             
                <table className="table table-striped" id="search-user">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Medical_History</th>
                            <th>Name</th>
                            <th>Date of birth</th>
                            <th>Gender</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Contact number</th>
                            <th>aadhar number</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                   
                                    <tr key={this.state.user.id}>
                                        <td>{this.state.user.id}</td>
                                        <td>{this.state.user.medical_history}</td>
                                        <td>{this.state.user.name}</td>
                                        <td>{this.state.user.dob}</td>
                                        <td>{this.state.user.gender}</td>
                                        <td>{this.state.user.email}</td>
                                        <td>{this.state.user.address}</td>
                                        <td>{this.state.user.contact_no}</td>
                                        <td>{this.state.user.aadharNumber}</td>
                                    </tr>
                            
                        }
                    </tbody>
                </table>
             </div>
            </div>
                    

            )
           

   }
  
}

export default GetVaccinatedPersonDetails;