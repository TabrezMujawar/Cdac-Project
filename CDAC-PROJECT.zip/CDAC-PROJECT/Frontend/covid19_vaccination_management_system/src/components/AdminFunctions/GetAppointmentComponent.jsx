import React from 'react';
import AppointmentService from '../../service/AppointmentService';
import AdminMainComponent from '../admin/AdminMainComponent';

class GetAppointmentComponent extends React.Component
{
   
  constructor(props){
    super(props)
    this.state ={
        appointment: '',
        appId: '',
        message: null
    }
    this.getAppointment = this.getAppointment.bind(this);
  }

  getAppointment=(app_id)=>{
    
    console.log(app_id)
    if(app_id!=="")
     {     
       AppointmentService.getAppointmentById(app_id)
          .then(res=> {
            console.log(res.data.result);
              
              this.setState({
                  appointment:res.data,
                  message:"Appointment fetched successfully"
              }) 
                document.getElementById('search-appointment').style.visibility = "visible";    
                document.getElementById('error').style.color="green";
          })
          .catch((err)=>{
            //document.getElementById('error').style.color="red";
            this.setState({message:"Invalid appointment id"});
            document.getElementById('search-appointment').style.visibility = "hidden";    
            document.getElementById('error').style.color="red";
          })
      }
     else
     {
            document.getElementById('search-appointment').style.visibility = "hidden";    
             document.getElementById('error').style.color="red";
              this.setState({message:"Please enter valid id"});

     } 
    
    
  }

       onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });

   render()
   {
            return (
                <div class="m row g-2">
                <div className="col-4">
                  <AdminMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                      <div className="row g-2">
                         <h4 id="error">{this.state.message}</h4>
                      </div>
                 <div className="row g-2">
                      <div class="col-md-3">  
                      <label for="appId" class="form-label">Enter Appointment Id</label>
                      </div>
                      <div class="col-md-4">
                     <input type="number" class="form-control" id="appId" name="appId" value={this.state.appId} onChange={this.onChange}/>
                     </div>
                     <div className="col-md-4">
                     <button className="btn btn-success"  style={{width:'100px'}} onClick={() => this.getAppointment(this.state.appId)}>Search</button>
                     </div>
                </div>
             
                <table className="table table-striped" id="search-appointment">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Appointment date</th>
                            <th>Appointment time</th>       
                        </tr>
                    </thead>
                    <tbody>
                        {
                   
                                    <tr key={this.state.appointment.id}>
                                    <td>{this.state.appointment.id}</td>
                                    <td>{this.state.appointment.booking_date}</td>
                                    <td>{this.state.appointment.booking_time}</td>
                                </tr>
                            
                        }
                    </tbody>
                </table>
             </div>
            </div>
                    

            )
           

   }
  
}

export default GetAppointmentComponent;