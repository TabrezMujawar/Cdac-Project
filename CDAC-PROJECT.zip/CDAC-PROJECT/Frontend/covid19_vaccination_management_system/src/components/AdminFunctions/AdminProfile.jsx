import React from 'react';
import AdminMainComponent from '../admin/AdminMainComponent';

class AdminProfileComponent extends React.Component
{
   
  constructor(props){
    super(props);
    this.state ={
        name: '',
        email: '',
        address: '',
        contact_no: ''
       
    }
    this.getProfile = this.getProfile.bind(this);
  }

  componentDidMount()
  {
    this.getProfile();
  }


  getProfile()
  {
    let details=JSON.parse(sessionStorage.getItem("details"));
    let adminID=details.result.id;
    // AdminService.getAdmin(adminID)
    fetch("http://localhost:6060/admin/"+adminID)
    .then(async (res)=> {
        console.log("In Admin");
        let admin =  await res.json();
        console.log(admin);
        this.setState({
        name: admin.result.name,
        email: admin.result.email,
        address: admin.result.address,
        contact_no: admin.result.contact_no
        })
    })
  }

   render()
   {
            return (
                       <div id="adminProfile" className="m row g-3">
                           
                           <div id="mainComponent" className="col-3">
                           <AdminMainComponent/>
                          </div>
                          
                          <div id="profile-component" className="col-8">
                           <center> <div className="row">
                                  <div class="row g-3">
                                  <div class="col-6 col-md-4">
                                  <label style={{fontWeight:'bold'}}>Name  : </label>
                                   </div>
                                   <div class="col-6 col-md-4">
                                   <label>{this.state.name}</label>     
                                   </div>
                                  </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <lable style={{fontWeight:'bold'}}>Email :</lable>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.email}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Address :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.address}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Contact :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.contact_no}</label>    
                                   </div>
                               </div>
                               </div></center>
                           </div>
                          </div>
                    

            )
           

   }

}

export default AdminProfileComponent