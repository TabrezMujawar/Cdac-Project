import React, { Component } from 'react'
import UserService from '../../service/UserService';
import AdminMainComponent from '../admin/AdminMainComponent';

class FetchAllUserComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            users: [],
            message: null
        }
        this.reloadUserList = this.reloadUserList.bind(this);
    }

    componentDidMount() {
        this.reloadUserList();
    }

    reloadUserList() {
        UserService.fetchUsers()
            .then((res) => {
                this.setState({users: res.data.result})
                console.log(this.state.users);
            });
            // UserService.getUsers().then(resp => {
            //     this.setState({ users: resp.data });
            //     console.log(this.state.users);
            // })
    }


    render() {
        return (
            <div class="m row g-2">
                <div className="col-4">
                  <AdminMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                <h2 className="text-center">User Details</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Medical History</th>
                            <th>Name</th>
                            <th>Data of birth</th>
                            <th>Gender</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Contact</th>
                            <th>Aadhar number</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.users.map(
                        user =>
                                    <tr key={user.id}>
                                        <td>{user.id}</td>
                                        <td>{user.medical_history}</td>
                                        <td>{user.name}</td>
                                        <td>{user.dob}</td>
                                        <td>{user.gender}</td>
                                        <td>{user.email}</td>
                                        <td>{user.address}</td>
                                        <td>{user.contact_no}</td>
                                        <td>{user.aadharNumber}</td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>
              </div>
            </div>
        );
    }

}

export default FetchAllUserComponent;