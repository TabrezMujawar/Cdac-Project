import React from 'react'
import AppointmentService from '../../service/AppointmentService';
import AdminMainComponent from '../admin/AdminMainComponent';

class FetchAllAppointmentComponent extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            appointments:[],
            message: null
        }
        this.reloadAppointmentList = this.reloadAppointmentList.bind(this);
    }

    componentDidMount() {
        this.reloadAppointmentList();
    }

    reloadAppointmentList() {
        AppointmentService.getallAppointment()
            .then(res => {
                console.log("In get all appointment")
                console.log(res.data);
                this.setState({appointments: res.data})
                console.log("Appointment : "+this.state.appointments);
            });
           
    }

    

  
    render()
     {
        return (
            <div class="m row g-2">
                <div className="col-4">
                  <AdminMainComponent/>
                  </div>
                  <div id="list" className="col-9">
                <h2 className="text-center">All Appointment Details</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>User Id</th>
                            <th className="hidden">Appointment Id</th>
                            <th>Appointment date</th>
                            <th>Appointment time</th>
                             </tr>                       
                    </thead>
                    
                    <tbody>
                        {
                           
                            this.state.appointments.map(
                                appt =>
                                    <tr key={appt.id}>
                                        <td>{appt.user.id}</td>
                                        <td>{appt.id}</td>
                                        <td>{appt.booking_date}</td>
                                        <td>{appt.booking_time}</td>
                                        <td>
                                           <button className="btn btn-primary" onClick={()=>this.props.history.push("/get_user")}>View User Details</button>
                                        </td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>
             </div>
            </div>
        )
    }

}

export default FetchAllAppointmentComponent;