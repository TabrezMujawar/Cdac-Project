import React, { Component } from 'react'
import StaffService from '../../service/StaffService';
import StaffMainComponent from '../staff/StaffMainComponent';

class UpdateStaffDetailsComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            id: '',
            name: '',
            email: '',
            password: '',
            address: '',
            contact_no: '',
            lab_no: ''
           
        }
        this.saveStaff = this.saveStaff.bind(this);
        this.reloadStaff = this.reloadStaff.bind(this);
    }

    validName()
         { 
          if(this.state.name==='')
          {
            this.setState({nameValidatedMessage:"Please enter valid name"});
            
            return false;
          }
          else
          {
            this.setState({nameValidatedMessage:""});
           
            return true;
          }
         }

         validEmail()
         { 
          if(this.state.email==='' || !this.state.email.includes("@") || !this.state.email.endsWith(".com"))
          {
            this.setState({emailValidatedMessage:"Please enter valid email"});
            
            return false;
          }
          else
          {
            this.setState({emailValidatedMessage:""});
         
            return true;
          }
         }

        /* validPassword()
         {
          if(this.state.password==='' || !(this.state.password.length<=10 && this.state.password.length>=5) )
          {
            this.setState({passwordValidatedMessage:"Password must contain at least 5 character and less than 10 characters"});
            return false;
          }
          this.setState({passwordValidatedMessage:""});
          return true;
         }
         */
         validAddress()
         {
          if(this.state.address==='')
          {
            this.setState({addressValidatedMessage:"Please enter valid address"});
            return false;
          }
          this.setState({addressValidatedMessage:""});
          return true;
         }

         validContact()
         {
           if(this.state.contact_no==='' ||  !this.state.contact_no.length===10)
          {
            this.setState({contactValidatedMessage:"Please enter valid mobile number"});
            return false;
          }
          this.setState({contactValidatedMessage:""});
          return true;
         }

         validLab()
         {
          if(this.state.contact_no==='')
          {
            this.setState({labValidatedMessage:"Please enter valid lab number"});
            return false;
          }
          this.setState({labValidatedMessage:""});
          return true;
         }

         


        validateStaff()
         {
         
             let isValid=true;
             if(!this.validName())
             {
               isValid=false;
             }   
             if(!this.validEmail())
             {
               isValid=false;
             }       
             if(!this.validAddress())
             {
               isValid=false;
             } 
             if(!this.validContact())
             {
               isValid=false;
             } 
             if(!this.validLab())
             {
               isValid=false;
             } 
            return isValid;

        }
         
        componentDidMount() {
            this.reloadStaff();
         
        }
       
         reloadStaff() {
      
            let details=JSON.parse(sessionStorage.getItem("details"));
            let staffID=details.result.id;
              StaffService.getStaffById(staffID)
             .then( (res)=> {
                console.log("In Staff");
                let staff =  res.data;
                console.log(staff);
                this.setState({
                id: staff.result.id,  
                name: staff.result.name,
                email: staff.result.email,
                address: staff.result.address,
                contact_no: staff.result.contact_no,
                lab_no : staff.result.lab_no
                })
              
            })
            
           
    }

    
    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    saveStaff = (e) => {
        if(this.validateStaff())
        {
        e.preventDefault();
        let staff = {id: this.state.id, name: this.state.name, email: this.state.email, address: this.state.address, contact_no: this.state.contact_no, lab_no: this.state.lab_no}
       StaffService.updateStaff(staff)
            .then(res => {
                document.getElementById("message").style.color="green";
                this.setState({message : 'Staff updated successfully.'});
               // this.props.history.push('/staff_update');
            })
            .catch(err =>{
              console.log(err);
              document.getElementById("message").style.color="red";
              this.setState({message : 'Staff updation failed.'});
            }
              );
        }
        else{
          e.preventDefault();
          this.setState({message : ''})
        }
       
    }

    render() {
        return (
            <div id="update_admin" className="m row ">
               
                      <div className="col-3">
                          <StaffMainComponent/>
                          </div>
                 <div id="update-profile-component" className="col-5"> 
                 <center><div className="row g-2">
                 <h4 id="message" >{this.state.message}</h4>
                  </div></center>
                  <center><div className="row g-3">
                <h4 className="text-center">Update Profile</h4>
                </div></center>
            
                   
               <center> <form>

                    <div  id="staff-update-form" className="form-group">
                        <label>Staff Name:</label>
                        <input  type="text" placeholder={this.state.name} name="name" className="form-control" defaultValue={this.state.name} onChange={this.onChange}  />
                        <p id="errors">{this.state.nameValidatedMessage}</p>
                    </div>

                    <div id="staff-update-form" className="form-group">
                        <label> Email:</label>
                        <input placeholder="Email" name="email" className="form-control" value={this.state.email} onChange={this.onChange}/>
                        <p id="errors">{this.state.emailValidatedMessage}</p>
                    </div>

                    <div  id="staff-update-form" className="form-group">
                        <label>Address:</label>
                        <textarea rows="2" id="address" className="form-control" placeholder="Enter Address" cols="20" name="address" value={this.state.address} onChange={this.onChange} ></textarea>
                        <p id="errors">{this.state.addressValidatedMessage}</p>
                    </div>

                    <div id="staff-update-form" className="form-group">
                        <label>Contact:</label>
                        <input type="text" placeholder="Contact" name="contact_no" className="form-control" value={this.state.contact_no} onChange={this.onChange}/>
                        <p id="errors">{this.state.contactValidatedMessage}</p>
                    </div>
                    
                    <div id="staff-update-form" className="form-group">
                        <label>Lab number:</label>
                        <input type="text" placeholder="Lab number" name="lab_no" className="form-control" value={this.state.lab_no} onChange={this.onChange}/>
                        <p id="errors">{this.state.contactValidatedMessage}</p>
                    </div>

                    <div className="form-group">
                    <button className="btn btn-success" onClick={this.saveStaff}>Update</button>
                    </div>
                   
                 
               
                </form></center>  
              
                </div>
               
                
            </div>
        );
    }
}

export default UpdateStaffDetailsComponent;