import React from 'react';
import StaffService from '../../service/StaffService';
import StaffMainComponent from '../staff/StaffMainComponent';
class StaffProfileComponent extends React.Component
{
   
  constructor(props){
    super(props);
    this.state ={
        name: '',
        email: '',
        address: '',
        contact_no: '',
        lab_no: ''
       
    }
    this.getProfile = this.getProfile.bind(this);
  }

  componentDidMount()
  {
    
    this.getProfile();
  }


  getProfile()
  {
      
    let details=JSON.parse(sessionStorage.getItem("details"));
    let staffID=details.result.id;
      StaffService.getStaffById(staffID)
     .then( (res)=> {
        console.log("In Admin");
        let staff =  res.data;
        console.log(staff);
        this.setState({
        name: staff.result.name,
        email: staff.result.email,
        address: staff.result.address,
        contact_no: staff.result.contact_no,
        lab_no : staff.result.lab_no
        })
    })
  }

   render()
   {
            return (
                       <div id="adminProfile" className="m row g-3">
                           
                           <div id="mainComponent" className="col-3">
                               <StaffMainComponent/>
                          </div>
                          
                          <div id="profile-component" className="col-8">
                           <center> <div className="row">
                                  <div class="row g-3">
                                  <div class="col-6 col-md-4">
                                  <label style={{fontWeight:'bold'}}>Name  : </label>
                                   </div>
                                   <div class="col-6 col-md-4">
                                   <label>{this.state.name}</label>     
                                   </div>
                                  </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <lable style={{fontWeight:'bold'}}>Email :</lable>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.email}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Address :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.address}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Contact :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.contact_no}</label>    
                                   </div>
                               </div>

                               <div class="row g-3">
                                   <div class="col-6 col-md-4">
                                     <label style={{fontWeight:'bold'}}>Contact :</label>    
                                   </div>
                                   <div class="col-6 col-md-4">
                                     <label>{this.state.lab_no}</label>    
                                   </div>
                               </div>

                               </div></center>
                           </div>
                          </div>
                    

            )
           

   }

}

export default StaffProfileComponent