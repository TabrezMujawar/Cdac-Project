import React from 'react';
import StaffMainComponent from '../staff/StaffMainComponent';

class StaffHomeComponent extends React.Component
{
   
   render()
   {
    let message=sessionStorage.getItem("message");
    let details=JSON.parse(sessionStorage.getItem("details"));
            return (
                        <div id="m" class="m row g-4">
                         <div className="col"> 
                          <StaffMainComponent/>
                          </div>  
                          <center><div id="current-component" className="col-8">
                           <div className="col">
                             
                           <h2 style={{fontSize:"2.5vw"}}>{message}........! Welcome <span style={{color:'blue'}}>{details.result.name}</span> !</h2>
                           </div>
                          
                           </div>
                           </center>
                       </div>
                       
                       
            )
           

   }

}

export default StaffHomeComponent