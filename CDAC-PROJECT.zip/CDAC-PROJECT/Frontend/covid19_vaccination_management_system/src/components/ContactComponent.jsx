import React from 'react';

class ContactComponent extends React.Component
{
   render()
   {
            return (
                       <div id="contact" className="row">
                        <div class="jumbotron jumbotron-fluid">
                           <div class="container">
                              <h1 class="display-4" style={{marginTop:"4rem",fontWeight:'inherit',color:"white"}}>Contact</h1>
                              <p class="lead" style={{color:"white",marginTop:"4rem",marginBottom:"4rem"}}>
                                 Helpline Number : +91-11-23978046 <br></br>
                                 Toll Free : 1075 <br></br>
                                 Helpline Email ID : wecare2021@vaccination.com </p>
                           </div>
                        </div>
                       </div>

            )
           

   }

}

export default ContactComponent;