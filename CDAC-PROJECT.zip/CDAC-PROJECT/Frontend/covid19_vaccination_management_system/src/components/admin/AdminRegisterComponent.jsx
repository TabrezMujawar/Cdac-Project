import React from "react";
import AdminService from "../../service/AdminService";

class AdminRegisterComponent extends React.Component

{
    constructor(props){
        super(props);
        this.state ={
            name: '',
            email: '',
            password: '',
            address: '',
            contact_no: ''
            
        }
       
        this.saveAdmin = this.saveAdmin.bind(this);
         
    }
           
       validName()
         { 
          if(this.state.name==='')
          {
            this.setState({nameValidatedMessage:"Please enter valid name"});
            
            return false;
          }
          else
          {
            this.setState({nameValidatedMessage:""});
           
            return true;
          }
         }

         validEmail()
         { 
          if(this.state.email==='' || !this.state.email.includes("@") || !this.state.email.endsWith(".com"))
          {
            this.setState({emailValidatedMessage:"Please enter valid email"});
            
            return false;
          }
          else
          {
            this.setState({emailValidatedMessage:""});
         
            return true;
          }
         }

         validPassword()
         {
          if(this.state.password==='' || !(this.state.password.length<=10 && this.state.password.length>=5) )
          {
            this.setState({passwordValidatedMessage:"Password must contain at least 5 character and less than 10 characters"});
            return false;
          }
          this.setState({passwordValidatedMessage:""});
          return true;
         }

         validAddress()
         {
          if(this.state.address==='')
          {
            this.setState({addressValidatedMessage:"Please enter valid address"});
            return false;
          }
          this.setState({addressValidatedMessage:""});
          return true;
         }

         validContact()
         {
           if(this.state.contact_no==='' ||  !this.state.contact_no.length===10)
          {
            this.setState({contactValidatedMessage:"Please enter valid mobile number"});
            return false;
          }
          this.setState({contactValidatedMessage:""});
          return true;
         }

        validAdmin()
         {
             let isValid=true;
             if(!this.validName())
             {
               isValid=false;
             }   
             if(!this.validEmail())
             {
               isValid=false;
             } 
             if(!this.validPassword())
             {
               isValid=false;
             }             
             if(!this.validAddress())
             {
               isValid=false;
             } 
             if(!this.validContact())
             {
               isValid=false;
             } 
            return isValid;
        }
         
         
 



    saveAdmin = (e) => {
     
      if(this.validAdmin())
      {
        e.preventDefault();
        let admin = {name: this.state.name, dob: this.state.dob, email: this.state.email, password: this.state.password, address: this.state.address, contact_no: this.state.contact_no};
         console.log("Name : "+this.state.name);
       
        
          AdminService.addAdmin(admin)
        
          .then(res => {
              document.getElementById("message").style.color="green";
              this.setState({message : 'Admin added successfully.'});
              this.props.history.push('/admin');
            })
            .catch(err=>
              { 
                document.getElementById("message").style.color="red";
                this.setState({message : 'Registration failed'});
              })
         }
       }
       
     onChange = (e) =>
    this.setState({ [e.target.name]: e.target.value });
            
      render()
    {
      
        return( 
            <div id="main" className="row">
           <div id="admin_register" class="row">
                  <center><h4 id="message">{this.state.message}</h4></center> 
            <h4 className="text-center">Register Admin</h4>
          
            <center><div class="card" id="adminRegisterCard">
             
            <form className="row g-1 needs-validation" id="userRegisterform" novalidate>
          
             <div class="row g-2">
            <div class="col-md-6">
                <label for="name" class="form-label">Name <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input placeholder="Enter name"  id="name" name="name" className="form-control" value={this.state.name} onChange={this.onChange} required/>
                 <p id="errors">{this.state.nameValidatedMessage}</p>
                 
             </div>

            <div className="col-md-6">
            <label for="email" class="form-label">Email <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input placeholder="Email"  id="email" name="email" className="form-control" value={this.state.email} onChange={this.onChange} required/>
                <p id="errors">{this.state.emailValidatedMessage}</p>
               
            </div>
        </div>

        <div className="row g-2">
            <div className="col-md-6">
            <label for="password" class="form-label">Password <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input type="password" id="password" placeholder="password" name="password" className="form-control" value={this.state.password} onChange={this.onChange} required/>
                <p id="errors">{this.state.passwordValidatedMessage}</p>
            </div>

            <div className="col-md-6">
            <label for="address" class="form-label">Address <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <textarea rows="2" id="address" className="form-control" placeholder="Enter Address" cols="20" name="address" value={this.state.address} onChange={this.onChange} required></textarea>
                <p id="errors">{this.state.addressValidatedMessage}</p>
           </div>
        </div>

       <div className="row g-2">
            <div className="col-md-6">
            <label for="contact_no" class="form-label">Contact <span style={{color:"red",fontWeight:"bolder"}}>*</span></label>
                <input type="text"  placeholder="Enter mobile number" name="contact_no" id="contact_no" className="form-control" value={this.state.contact_no} onChange={this.onChange} required/>
                <p id="errors">{this.state.contactValidatedMessage}</p>
            </div>
       </div> 
           <div className="row g-2">
            <center><button type="button" id="registerButton" class="btn btn-primary" onClick={this.saveAdmin}>Register</button></center>                                                                                     
            </div>
          </form>
          </div></center>
        </div>
        </div>
        )
    }


}

export default AdminRegisterComponent;