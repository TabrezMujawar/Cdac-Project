import React from "react";
import AboutusComponent from "./AboutusComponent";
import ContactComponent from "./ContactComponent";
import ServiceComponent from "./ServiceComponent";

class HomepageController extends React.Component
{
         render()
         {
                return(      
                  <div id="main" className="row" style={{marginTop:"2.9rem"}}>
                    <div className="container  overflow-visible">
                      <div className="row "></div>
                      <div id="myCarousel" className="carousel slide"  data-bs-ride="carousel">
                        <div className="carousel-inner">
                      <div className="carousel-item active" data-bs-interval="2000">
                        <img src="/images/banner1.jpg" id="slideImage"  alt="banner1"/>
                      </div>
                      <div className="carousel-item"  data-bs-interval="2000">
                        <img src="/images/banner2.jpg" id="slideImage" alt="banner2"/>
                      </div>
                      <div className="carousel-item"  data-bs-interval="2000">
                        <img src="/images/banner3.jpg" id="slideImage" alt="banner3"/>
                      </div>
                      <div className="carousel-item"  data-bs-interval="2000">
                        <img src="/images/banner4.jpg" id="slideImage" alt="banner4"/>
                      </div>        
                    </div>
                    <button className="carousel-control-prev" type="button" data-bs-target="#myCarousel"  data-bs-slide="prev">
                        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Previous</span>
                      </button>
                      <button className="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
                        <span className="carousel-control-next-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Next</span>
                      </button>
                  </div>
                  </div>

                  <div id="jumbotron" class="container">
                        <div class="row">
                          <div class="col-sm">
                          <div class="jumbotron jumbotron-fluid">
                            <div class="container">
                                <h1 className="display-6" style={{fontWeight:"inherit"}}>Vaccination System</h1>
                                  <p className="lead" >A powerful IT platform for vaccination management integrates all parties involved in the vaccination process in a holistic approach - from the pharmaceutical manufacturer to the vaccination centre to the citizens to be vaccinated. This ensures the smooth handling of the entire vaccination process as well as a high level of information transparency.
                                      </p>
                                      </div>
                                        </div>
                            </div>

                                      <div class="col-sm">
                                            <div class="jumbotron jumbotron-fluid">
                                                <div class="container">
                                                    <h1 className="display-6" style={{fontWeight:"inherit"}}>Benefits of Vaccination</h1>
                                                    <p className="lead"> We understand that some people may be concerned about getting vaccinated now that COVID-19 vaccines are available in the India. While more COVID-19 vaccines are being developed as quickly as possible. Safety is a top priority, and there are many reasons to get vaccinated.
                                                    </p>
                                                    </div>
                                                      </div>
                                              </div>

                                                <div class="col-sm">
                                                      <div class="jumbotron jumbotron-fluid">
                                                        <div class="container">
                                                          <h1 className="display-6" style={{fontWeight:"inherit"}}>Vaccination Availability</h1>
                                                            <p className="lead">All COVID-19 vaccines currently available in the India have been shown to be highly effective at preventing COVID-19.Experts continue to conduct more studies about the effect of COVID-19 vaccination on severity of illness from COVID-19 as well as its ability to keep people from spreading the virus that causes COVID-19. 
                                                                </p>
                                                                  </div>
                                                                    </div>
                                                              </div>

                                                                                 </div>
                                                                                 </div>
                                                                                 <AboutusComponent/>
                                                                                 <ServiceComponent/>
                                                                                 <ContactComponent/>
                                     
                                     </div>
               )

         }

}

export default HomepageController;