import React from 'react';

class AboutusComponent extends React.Component
{
   render()
   {
            return (
                       <div id="aboutUs" className="row g-3" >
                              <div class="jumbotron jumbotron-fluid">
                              <div class="container" id="about-us-jumbotron">
                                 <h1 class="display-4" style={{fontWeight:"inherit"}}>About us</h1>
                                 <p class="lead">Covid 19 Vaccination Management System is a platform which manages entire
                                                 vaccination process from booking an appointment for a vaccination to being
                                                 vaccinated. Thanks to the work of thousands of researchers around the world who
                                                 dedicate their lives to it, we often have a good understanding of how it is
                                                possible to make progress against the pandemics we are facing. In the coming 
                                                time this project can be extended to a larger community/area rather than a small 
                                                group of people of a particular area. We can also implement this project in future
                                                 , for other vaccine of different diseases like measles , hepatitis-B etc on a
                                                larger scale and not only for COVID-19 , this will help to have a digital records
                                                 of the vaccine given to the people and will help to vaccinate them with the doses 
                                                in the required interval of time even if they forgot to take the vaccine and this will
                                                help India to get free from such deadly diseases just like we are a proud 
                                                polio free country according to World Health Organization (WHO).
                                 </p>
                              </div>
                              </div>
                       </div>

            )
           

   }

}

export default AboutusComponent;