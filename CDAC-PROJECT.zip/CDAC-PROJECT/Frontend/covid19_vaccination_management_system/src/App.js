
import HomepageComponent from "./components/HomepageComponent";
import RegisterComponent from "./components/user/RegisterComponent";
import AdminRegisterComponent from "./components/admin/AdminRegisterComponent";
import StaffRegisterComponent from "./components/staff/StaffRegisterComponent";
import LoginComponent from "./components/LoginComponent";
import StaffMainComponent from "./components/staff/StaffMainComponent";
import AdminProfileComponent from "./components/AdminFunctions/AdminProfile";
import AdminHomeComponent from "./components/AdminFunctions/AdminHomeComponent";
import EditAdminComponent from "./components/AdminFunctions/EditAdminComponent";
import FetchAllStaffComponent from "./components/AdminFunctions/FetchAllStaffComponent.jsx";
import GetStaffComponent from "./components/AdminFunctions/GetStaffComponent";
import FetchAllUserComponent from "./components/AdminFunctions/FetchAllUserComponent";
import GetUserComponent from "./components/AdminFunctions/GetUserComponent";
import FetchAllAppointmentComponent from "./components/AdminFunctions/FetchAllAppointmentComponent";
import GetAppointmentComponent from "./components/AdminFunctions/GetAppointmentComponent";
import AddVaccinatedPersonDetails from "./components/AdminFunctions/AddVaccinatedPersonDetails";
import FetchAllVaccinatedPersonsComponent from "./components/AdminFunctions/FetchAllVaccinatedPersonsComponent";
import UpdateVaccinationDetailsComponent from "./components/AdminFunctions/UpdateVaccinationDetailsComponent";
import GetVaccinatedPersonDetails from "./components/AdminFunctions/GetVaccinatedPersonDetails";
import LogoutComponent from "./components/LogoutComponent";
import UserHomeComponent from "./components/UserFunctions/UserHomeComponent";
import UserProfileComponent from "./components/UserFunctions/UserProfileComponent";
import UpdateUserDetailsComponent from "./components/UserFunctions/UpdateUserDetailsComponent";
import BookAppointmentComponent from "./components/UserFunctions/BookAppointmentComponent";
import UserAppointmentDetailsComponent from "./components/UserFunctions/UserAppointmentDetailsComponent";
import StaffHomeComponent from "./components/StaffFunctions/StaffHomeComponent";
import StaffProfileComponent from "./components/StaffFunctions/StaffProfileComponent";
import UpdateStaffDetailsComponent from "./components/StaffFunctions/UpdateStaffDetailsComponent";
import DeleteAccountComponent from "./components/DeleteAccountComponent";
import ChangePasswordComponent from "./components/ChangePasswordComponent";
import { BrowserRouter as Router, Redirect, Route, Switch } from 'react-router-dom'
import "./index.css";
import "./styles/register.css";
import "./styles/login.css";
import "./styles/Main.css";
import ForgetPasswordComponent from "./components/ForgetPasswordComponent";




function App() {
  return (
    <div className="App">
      <div id="top" className="row" >
         <nav id="nav"  className="navbar navbar-expand-lg navbar-light">
           <div className="col">
           <a href="/" className="navbar-brand col text-white" id="Appname" >Vaccination System</a>
           <img className="col" src="./icons/vaccine-logo1.png" alt="user-logo" id="logo"></img>
           </div>
          
            <button className="navbar-toggler navbar-toggler-right" type="button" href="#navbarDropdown" style={{borderColor:"white",color:"white"}} data-bs-toggle="collapse" data-bs-target="#navbarDropdown" aria-controls="navbarDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon" style={{backgroundColor:"lightcyan"}}></span>
              </button>
               
                 <div className="collapse navbar-collapse" id="navbarDropdown">
                     <ul className="navbar-nav">
                       <li className="nav-item active">
                        <a className="nav-link text-white" aria-current="page" href="/">Home</a>
                      </li>
                     <li className="nav-item">
                       <a className="nav-link text-white" href="/#aboutUs">About us</a>
                       </li>
                       <li className="nav-item">
                          <a className="nav-link text-white" href="/#services">Services</a>
                          </li>
                          <li className="nav-item">
                              <a className="nav-link text-white" href="/login">Login</a>
                              </li>
                              <li className="nav-item">
                              <a className="nav-link text-white" href="/user">Register</a>
                              </li>
                            <li className="nav-item">
                             <a className="nav-link text-white" href="/#contact">Contact</a>
                           </li>
                       </ul>
                       </div>
                       </nav>
                       </div>
           <Router>
              <div >
                  <Switch>
                      <Route path="/" exact component={HomepageComponent} />
                      <Route path="/userpage" component={UserHomeComponent} />
                      <Route path="/user" component={RegisterComponent} />
                      <Route path="/users" component={FetchAllUserComponent} />
                      <Route path="/get_user" component={GetUserComponent} />  
                      <Route path="/user_profile" component={UserProfileComponent} />   
                      <Route path="/user_update" component={UpdateUserDetailsComponent} />   
                      <Route path="/show_details" component={GetVaccinatedPersonDetails} />  
                      <Route path="/admin" component={AdminRegisterComponent} />
                      <Route path="/staff" component={StaffRegisterComponent} />
                      <Route path="/staffpage" component={StaffHomeComponent} />
                      <Route path="/staff_profile" component={StaffProfileComponent} />
                      <Route path="/staff_update" component={UpdateStaffDetailsComponent} />
                      <Route path="/login" component={LoginComponent} />
                      <Route path="/adminpage" component={AdminHomeComponent} />
                      <Route path="/staffpage" component={StaffMainComponent} />
                      <Route path="/staff_add" component={StaffRegisterComponent} />
                      <Route path="/get_all_staff" component={FetchAllStaffComponent} />
                      <Route path="/get_staff" component={GetStaffComponent} />
                      <Route path="/profile" component={AdminProfileComponent} />
                      <Route path="/admin_update" component={EditAdminComponent} />
                      <Route path="/appointments" component={FetchAllAppointmentComponent} />
                      <Route path= "/get_appointment" component={GetAppointmentComponent} />
                      <Route path= "/add_vaccinated_person" component={AddVaccinatedPersonDetails} />
                      <Route path= "/vaccinated_persons" component={FetchAllVaccinatedPersonsComponent} />
                      <Route path= "/update_vaccination_person" component={UpdateVaccinationDetailsComponent} />
                      <Route path="/book_appointment" component={BookAppointmentComponent} />
                      <Route path="/appointment_details" component={UserAppointmentDetailsComponent} />
                      <Route path="/delete" component={DeleteAccountComponent}/>
                      <Route path="/change_password" component={ChangePasswordComponent}/>
                      <Route path="/forget_password" component={ForgetPasswordComponent}/>
                      <Route path="/logout" component={LogoutComponent} />
                  </Switch>
              </div>
          </Router>
    </div>
  );
}

export default App;
