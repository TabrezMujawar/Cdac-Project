import axios from 'axios';

const USER_API_BASE_URL = 'http://localhost:6060/user';

class UserService {

    fetchUsers() {
        return axios.get(USER_API_BASE_URL);
    }

    fetchUserById(userId) {
        return axios.get(USER_API_BASE_URL + '/' + userId);
    }

    fetchUserByAadharNumber(aadhar){
        return axios.get(USER_API_BASE_URL + '/details/' + aadhar);
    }

    deleteUser(userId) {
        return axios.delete(USER_API_BASE_URL + '/' + userId);
    }

    addUser(user) {
        return axios.post(""+USER_API_BASE_URL, user);
    }

    editUser(user) {
        return axios.put(USER_API_BASE_URL + '/' + user.id, user);
    }

}

export default new UserService();