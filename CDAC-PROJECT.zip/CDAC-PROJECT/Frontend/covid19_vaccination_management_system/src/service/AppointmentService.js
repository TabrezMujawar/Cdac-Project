import axios from 'axios';

const APPOINTMENT_API_BASE_URL = 'http://localhost:6060/appointment';

class AppointmentService {

    //This functions all in admin
    addAppointment(user_id,app) {
        return axios.post(APPOINTMENT_API_BASE_URL + '/' + user_id, app);
    }

    getallAppointment() {
        return axios.get(APPOINTMENT_API_BASE_URL);
    }
     
    getAppointmentById(app_id)
    {
        return axios.get(APPOINTMENT_API_BASE_URL + '/' + app_id);
    }
    
    delAppointment(userId,app_id)
    {
        return axios.delete(APPOINTMENT_API_BASE_URL + '/' + userId + '/' +  app_id);
    }

}

export default new AppointmentService();