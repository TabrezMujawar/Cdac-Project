import axios from 'axios';

const RESETPASSWORD_API_BASE_URL = 'http://localhost:6060/reset';

class ForgetPasswordService {


    sendResetlink(details)
    {
        return axios.post(RESETPASSWORD_API_BASE_URL,details);
    }

    resetPassword(d)
    {
        return axios.post(RESETPASSWORD_API_BASE_URL + '/password' ,d)
    }



}

export default new ForgetPasswordService()