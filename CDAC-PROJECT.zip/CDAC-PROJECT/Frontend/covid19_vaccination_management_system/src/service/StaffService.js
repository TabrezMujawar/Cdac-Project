import axios from 'axios';

const STAFF_API_BASE_URL = 'http://localhost:6060/staff';

class StaffService {

    //This functions all in admin
    addStaff(admin_id,staff) {
        return axios.post(""+STAFF_API_BASE_URL + '/' + admin_id, staff);
    }

    getAllStaff() {
        return axios.get(STAFF_API_BASE_URL);
    }
     
    getStaffById(staffId)
    {
        return axios.get(STAFF_API_BASE_URL + '/' + staffId);
    }

    updateStaff(staff) {
        return axios.put(STAFF_API_BASE_URL + '/' + staff.id, staff);
    }
    
    deleteStaff(adminId,staffId)
    {
        return axios.delete(STAFF_API_BASE_URL + '/' + adminId + '/' + staffId);
    }

}

export default new StaffService();