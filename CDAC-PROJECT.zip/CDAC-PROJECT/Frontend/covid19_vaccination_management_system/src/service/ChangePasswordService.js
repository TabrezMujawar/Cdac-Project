import axios from 'axios';

const CHANGEPASSWORD_API_BASE_URL = 'http://localhost:6060/changepassword';

class ChangePassword {


    changePassword(details)
    {
        return axios.post(CHANGEPASSWORD_API_BASE_URL,details);
    }

}

export default new ChangePassword()