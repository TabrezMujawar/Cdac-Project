import axios from 'axios';

const LOGIN_API_BASE_URL = 'http://localhost:6060/login';

class LoginService {

    //This functions all in admin
    authenticateRole(role,username,password) {
        return axios.post(LOGIN_API_BASE_URL,{role,username,password});
    }

}

export default new LoginService();