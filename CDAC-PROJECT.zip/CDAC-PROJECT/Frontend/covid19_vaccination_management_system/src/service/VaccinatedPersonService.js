import axios from 'axios';

const VACCINATED_API_BASE_URL = 'http://localhost:6060/vd';

class VaccinatedPersonService {

    //This functions all in admin
    addVccPerson(vc_person) {
        return axios.post(VACCINATED_API_BASE_URL,vc_person);
    }

    getallVccPerson() {
        return axios.get(VACCINATED_API_BASE_URL);
    }
     
    getVccPersonById(vc_id)
    {
        return axios.get(VACCINATED_API_BASE_URL + '/' + vc_id);
    }

    updateVccPersonById(vccId,vcc)
    {
        return axios.put(VACCINATED_API_BASE_URL + '/' + vccId,vcc);
    }
    
    deleteVccPerson(vc_id)
    {
        return axios.delete(VACCINATED_API_BASE_URL + '/' + vc_id);
    }

}

export default new VaccinatedPersonService();