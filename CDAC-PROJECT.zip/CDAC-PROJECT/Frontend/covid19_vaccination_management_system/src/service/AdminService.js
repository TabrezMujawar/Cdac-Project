import axios from 'axios';

const ADMIN_API_BASE_URL = 'http://localhost:6060/admin';

class AdminService {


    getAdmin(adminid)
    {
        return  axios.get(ADMIN_API_BASE_URL + '/', adminid);
    }


    addAdmin(admin) {
        return axios.post(""+ADMIN_API_BASE_URL, admin);
    }

    editAdmin(admin) {
        return axios.put(ADMIN_API_BASE_URL + '/' + admin.id, admin);
    }

   
    delAdmin(adminId)
    {
        return axios.delete(ADMIN_API_BASE_URL + '/' + adminId);
    }

}

export default new AdminService()