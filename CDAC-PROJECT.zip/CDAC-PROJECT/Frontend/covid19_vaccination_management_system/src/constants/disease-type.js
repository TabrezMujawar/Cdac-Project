
export const none="None";
export const heart_disease="Heart disease";
export const respiratory_disease="Respiratory disease";
export const other_disease="Other disease";