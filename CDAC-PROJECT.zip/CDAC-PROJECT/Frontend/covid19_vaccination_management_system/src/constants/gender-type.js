
export const male="Male";
export const female="Female";
export const other="Other";