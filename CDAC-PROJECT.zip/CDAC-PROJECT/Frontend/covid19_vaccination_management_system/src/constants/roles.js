export const admin="ADMIN";
export const user="USER";
export const staff="STAFF";