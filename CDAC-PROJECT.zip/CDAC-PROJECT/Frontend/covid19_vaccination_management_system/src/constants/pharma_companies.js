
export const bharat_biotech="BHARAT_BIOTECH";
export const serum_institue="SERUM_INSTITUTE";
export const zydus_cadia="ZYDUS_CADILA";
export const panacea_biotech="PANACEA_BIOTECH";