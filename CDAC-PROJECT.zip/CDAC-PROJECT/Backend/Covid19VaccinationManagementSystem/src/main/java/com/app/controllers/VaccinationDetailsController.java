package com.app.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Admin;
import com.app.pojos.VaccinationDetails;
import com.app.service.IVaccinationDetailsService;

@RestController
@RequestMapping("/vd")
@CrossOrigin
public class VaccinationDetailsController {
	               //dependency injection
	                @Autowired
	               private IVaccinationDetailsService vdService;
	               
	               public VaccinationDetailsController() {
					System.out.println("In constr of VaccinationDetailsController ");
				} 
	               //store vaccination details
		             @PostMapping
		             public  ResponseEntity<?> storeVaccinationDetails(@RequestBody VaccinationDetails vcc_detail)
		             {
		            	 System.out.println("In add vaccination details");
		            	  try {
			        		   return new ResponseEntity<>(vdService.storeVaccinationDetails(vcc_detail),HttpStatus.CREATED);
			        	   }
			        	   catch(RuntimeException e)
			        	   {
			        		   return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			        	   }	 
		             }
		             
		             //get vaccination details by id
		             @GetMapping("/{vd_id}")
		             public VaccinationDetails getVaccinationDetailsById(@PathVariable int vd_id)
		             {
		            	 System.out.println("In  get vaccination details by id ");
		            	 return vdService.getVaccinationDetailsById(vd_id);
		             }
		               
		             //get all vaccination details
		             @GetMapping
		             public ResponseEntity<?> getAllVaccinationDetails()
		             {
		            	 System.out.println("In get all vaccination details");
			             return new ResponseEntity<>(vdService.getAllVaccinationDetails(),HttpStatus.OK);        	  
		             }
		             
		             //update vaccination details
		             @PutMapping("/{vid}")
		             public ResponseEntity<?> updateVaccinationDetailsById(@PathVariable int vid,@RequestBody VaccinationDetails vcc_details)
			            {
		            	   System.out.println("In update vaccination details");
				           return new ResponseEntity<>(vdService.updateVaccinationDetails(vid,vcc_details),HttpStatus.OK);        	  
				        	   
			            }
	
		             
		             //delete vaccination details
		            @DeleteMapping("/{v_id}")
		            public ResponseEntity<?> deleteVaccinationDetailsById(@PathVariable int v_id)
		            {
		            	 System.out.println("In delete vaccination details");
			        
			             return new ResponseEntity<>(vdService.deleteVaccinationDetailsById(v_id),HttpStatus.OK);
			        	  
			        	   
		            }
		             
	               
	               

}
