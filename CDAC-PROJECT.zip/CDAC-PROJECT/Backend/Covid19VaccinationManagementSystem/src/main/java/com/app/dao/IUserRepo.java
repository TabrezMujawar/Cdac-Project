package com.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Admin;
import com.app.pojos.User;

public interface IUserRepo extends JpaRepository<User,Integer>{
	Optional<User> findDistinctByEmailAndPassword(String username,String password);
	Optional<User> findByAadharNumber(String aadhar_number);
	Optional<User> findByEmail(String email);

}
