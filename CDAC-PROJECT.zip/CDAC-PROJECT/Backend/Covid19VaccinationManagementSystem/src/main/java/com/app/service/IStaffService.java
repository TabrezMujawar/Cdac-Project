package com.app.service;

import java.util.List;

import com.app.dto.ChangePasswordDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserDTO;
import com.app.pojos.Staff;
import com.app.pojos.User;

public interface IStaffService  {
	 //staff registration
	 StaffDTO registerStaff(int admin_id,Staff s);
	 //staff authentication
	 StaffDTO authenticateStaff(String username,String password);
	 //change password
	 ChangePasswordDTO changePassword(String email,String oldPassword,String newPassword);
	//forget Password
	 StaffDTO forgetPassword(String email,String newPassword);
	 //get staff by id
	 StaffDTO getStaffById(int staffid);
	//get user by email
	 StaffDTO getByEmail(String email);
     //get all staff
	 List<StaffDTO> getAllStaff();
	 //update staff details
	 StaffDTO updateStaffDetails(int staffid,StaffDTO staffDTO);
	  //delete staff by id
	 StaffDTO deleteStaffById(int ad_id,int staffid);

	

}
