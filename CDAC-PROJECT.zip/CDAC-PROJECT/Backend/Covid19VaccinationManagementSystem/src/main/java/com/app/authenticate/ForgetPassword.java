package com.app.authenticate;

import com.app.enums.Role;

public class ForgetPassword {
	
	private Role role;
	private String email;
	private String newPassword;
	
	public ForgetPassword() {
		// TODO Auto-generated constructor stub
	}

	

	public ForgetPassword(Role role, String email, String newPassword) {
		super();
		this.role = role;
		this.email = email;
		this.newPassword = newPassword;
	}

   
	

	public Role getRole() {
		return role;
	}



	public void setRole(Role role) {
		this.role = role;
	}



	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}



	@Override
	public String toString() {
		return "ForgetPassword [role=" + role + ", email=" + email + ", newPassword=" + newPassword + "]";
	}

	
	

}
