package com.app.service;

import com.app.dto.AdminDTO;
import com.app.dto.ChangePasswordDTO;
import com.app.pojos.Admin;

public interface IAdminService {
	
	     //admin registration
		 AdminDTO registerAdmin(Admin a);
		//admin authentication
	    AdminDTO authenticateAdmin(String username,String password);
	    //change password
	    ChangePasswordDTO changePassword(String email,String oldPassword,String newPassword);
	    //find by email
	    AdminDTO getByEmail(String email);
	    //forget password
	    AdminDTO forgetPassword(String email,String newPassword);
	    
	    AdminDTO getAdminbyid(int adminId);
		AdminDTO updateAdmin(int adminId,AdminDTO a);
		AdminDTO deleteAdmin(int adminId);
		

}
