package com.app.service;

import java.sql.SQLException;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IAppointmentRepo;
import com.app.dao.IUserRepo;
import com.app.exceptions.ExceptionHandling;
import com.app.pojos.Appointment;
import com.app.pojos.User;

@Service
@Transactional
public class AppointmentServiceImpl implements IAppointmentService {
         //dependency injection
	      @Autowired
         private IAppointmentRepo appRepo;	
	      @Autowired
	      private IUserRepo userRepo;
	
	@Override
	public Appointment bookAppointment(int user_id,Appointment a) {
		 Optional<User> opUser=userRepo.findById(user_id);
		 User u=opUser.orElseThrow(()-> new ExceptionHandling("Invalid user id"));
		 u.addAppointment(a);
		 Appointment app= appRepo.save(a);
		 //app.setStatus(AppointmentStatus.BOOKED);
	     return app;
	}

	@Override
	public Appointment getAppointmentById(int app_id) {
		Optional<Appointment> opAppointment= appRepo.findById(app_id);
		Appointment appointment= opAppointment.orElseThrow(()->new ExceptionHandling("Invalid appointment id"));
		return appointment;
	}

	@Override
	public List<Appointment> getAllAppointments() {
	       return appRepo.findAll();
	}

	@Override
	public Appointment deleteAppointmentById(int uid,int app_id) {
		Optional<User> opUser=userRepo.findById(uid);
		User u=opUser.orElseThrow(()-> new ExceptionHandling("Invalid user id"));
		Optional<Appointment> opAppointment= appRepo.findById(app_id);
		Appointment delapp= opAppointment.orElseThrow(()->new ExceptionHandling("Invalid appointment id"));
		u.removeAppointment(delapp);
		appRepo.deleteById(app_id);
		return delapp;
	}

}
