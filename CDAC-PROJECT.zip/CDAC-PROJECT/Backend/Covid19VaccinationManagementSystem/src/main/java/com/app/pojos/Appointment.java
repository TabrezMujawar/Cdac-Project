package com.app.pojos;

import java.time.LocalDate;

import java.time.LocalDateTime;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.app.enums.BookingSlots;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "appointment",
           uniqueConstraints= @UniqueConstraint(columnNames={"booking_date","booking_time"})   
		)
public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(length = 40,nullable = false)
	private String booking_date=LocalDate.now().plusDays(1).toString();
	@Enumerated(EnumType.STRING)
	@Column(length = 40,nullable = false)
	private BookingSlots booking_time;
	@OneToOne(optional = false)
	@JoinColumn(name = "user_id",nullable = false)
	private User user;
	
	public Appointment()
	{
		System.out.println("In constr of Appointment");
	}

	public Appointment(String booking_date, BookingSlots booking_time) {
		super();
		this.booking_date = booking_date;
		this.booking_time = booking_time;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBooking_date() {
		return booking_date;
	}

	public void setBooking_date(String booking_date) {
		this.booking_date = booking_date;
	}

	public BookingSlots getBooking_time() {
		return booking_time;
	}

	public void setBooking_time(BookingSlots booking_time) {
		this.booking_time = booking_time;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", booking_date=" + booking_date + ", booking_time=" + booking_time
				+  "]";
	}

	

	

}
