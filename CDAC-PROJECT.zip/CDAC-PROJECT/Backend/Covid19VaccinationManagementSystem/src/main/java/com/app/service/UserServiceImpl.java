package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IUserRepo;
import com.app.dto.AdminDTO;
import com.app.dto.ChangePasswordDTO;
import com.app.dto.UserDTO;
import com.app.exceptions.ExceptionHandling;
import com.app.pojos.Admin;
import com.app.pojos.User;

@Service
@Transactional
public class UserServiceImpl implements IUserService {
            //dependency injection
	      @Autowired
	      private IUserRepo userRepo;
	      @Autowired
	      private EntityManager mgr;
	      
	
	@Override
	public UserDTO registerUser(User u) {
		User user= userRepo.save(u);
		UserDTO user_dto=new UserDTO();
		 //BeanUtils.copyProperties api is used to copy persistent user to user dto
        BeanUtils.copyProperties(user,user_dto);//takes matching data members and ignores unmatching;
 	 	return user_dto;
	}

	@Override
	public UserDTO authenticateUser(String username,String password) {
		// String jpql="select u from User u where u.email=:username and u.password=:password";
	     //Optional<User> opUser=Optional.of(mgr.createQuery(jpql,User.class).setParameter("username",username).setParameter("password",password).getSingleResult());
	   User user=userRepo.findDistinctByEmailAndPassword(username, password).orElseThrow(()->new ExceptionHandling("Invalid username or password"));
	   UserDTO user_dto=new UserDTO();
		 //BeanUtils.copyProperties api is used to copy persistent user to user dto
       BeanUtils.copyProperties(user,user_dto);//takes matching data members and ignores unmatching;
       return user_dto;
	}

     	
	
	@Override
	public ChangePasswordDTO changePassword(String email, String oldPassword, String newPassword) {
		 User user=userRepo.findDistinctByEmailAndPassword(email,oldPassword).orElseThrow(()->new ExceptionHandling("Invalid username or password"));
	     user.setPassword(newPassword);
	     User u=userRepo.save(user);
	     ChangePasswordDTO cp=new ChangePasswordDTO();
	     BeanUtils.copyProperties(u,cp);
	     return cp;
	}

	//forget password
	
	@Override
	public UserDTO getUserById(int userid) {
		Optional<User> opUser= userRepo.findById(userid);
		User user= opUser.orElseThrow(()->new ExceptionHandling("Invalid user id"));
		UserDTO user_dto=new UserDTO();
		 //BeanUtils.copyProperties api is used to copy persistent user to user dto
        BeanUtils.copyProperties(user,user_dto);//takes matching data members and ignores unmatching;
         
	 	return user_dto;
	}

	@Override
	public UserDTO forgetPassword(String email, String newPassword) {
		User u=userRepo.findByEmail(email).orElseThrow(()-> new ExceptionHandling("Invalid email id"));
		u.setPassword(newPassword);
		UserDTO user_dto=new UserDTO();
		 //BeanUtils.copyProperties api is used to copy persistent user to user dto
       BeanUtils.copyProperties(u,user_dto);//takes matching data members and ignores unmatching;  
	 	return user_dto;
	}

	//get user by aadhar number
	@Override
	public UserDTO getUserByAadharNumber(String aadhar_number) {
	   User user= userRepo.findByAadharNumber(aadhar_number).orElseThrow(()-> new ExceptionHandling("Invalid aadhar number"));
	   UserDTO user_dto=new UserDTO();
		 //BeanUtils.copyProperties api is used to copy persistent user to user dto
       BeanUtils.copyProperties(user,user_dto);//takes matching data members and ignores unmatching;
	   return user_dto;
	} 
	

	@Override
	public UserDTO getByEmail(String email) {
		User u=userRepo.findByEmail(email).orElseThrow(()->new ExceptionHandling("Invalid email"));
		UserDTO u_dto=new UserDTO();
		   BeanUtils.copyProperties(u,u_dto);
		   return u_dto;
	    
	}
	
	@Override
	public List<UserDTO> getAllUsers() {
		List<User> userList=userRepo.findAll();
		List<UserDTO> list=new ArrayList<>();
		userList.forEach(u -> {
			UserDTO user_dto= new UserDTO();
		    BeanUtils.copyProperties(u,user_dto);
		    list.add(user_dto);
		});
		return list;
	}

	

	@Override
	public UserDTO updateUserDetails(int userid,UserDTO userDTO) {
		  Optional<User> opUser=userRepo.findById(userid);
		  User updateUser = opUser.orElseThrow(()->new ExceptionHandling("Invalid user id"));
		  BeanUtils.copyProperties(userDTO,updateUser,"password");
		  User user=userRepo.save(updateUser);
		  UserDTO user_dto=new UserDTO();
			//BeanUtils.copyProperties api is used to copy persistent user to user dto
	       BeanUtils.copyProperties(user,user_dto);//takes matching data members and ignores unmatching;
		   return user_dto;
		}

	@Override
	public UserDTO deleteUserById(int userid) {
		  Optional<User> opUser=userRepo.findById(userid);
		  User deluser = opUser.orElseThrow(()->new ExceptionHandling("Invalid user id"));
		  userRepo.deleteById(userid);
		  UserDTO user_dto=new UserDTO();
			//BeanUtils.copyProperties api is used to copy persistent user to user dto
	      BeanUtils.copyProperties(deluser,user_dto);//takes matching data members and ignores unmatching;
		  return user_dto;
	}

}
