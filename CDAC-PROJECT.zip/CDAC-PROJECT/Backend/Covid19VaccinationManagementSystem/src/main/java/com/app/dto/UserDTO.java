package com.app.dto;

import java.time.LocalDate;

import com.app.pojos.Appointment;

public class UserDTO {
	private Integer id;
	private String medical_history;
	private String name;
	private LocalDate dob;
	private String gender;
	private String email;
	private String address;
	private String contact_no;
	private String aadharNumber;
	private Appointment appointment;	
	
	public UserDTO() {
		System.out.println("In user dto");
	}

	public UserDTO(Integer id, String medical_history, String name, LocalDate dob, String gender, String email,
			String address, String contact_no, String aadharNumber) {
		super();
		this.id = id;
		this.medical_history = medical_history;
		this.name = name;
		this.dob = dob;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.contact_no = contact_no;
		this.aadharNumber = aadharNumber;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMedical_history() {
		return medical_history;
	}

	public void setMedical_history(String medical_history) {
		this.medical_history = medical_history;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}

	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", medical_history=" + medical_history + ", name=" + name + ", dob=" + dob
				+ ", gender=" + gender + ", email=" + email + ", address=" + address + ", contact_no=" + contact_no
				+ ", aadharNumber=" + aadharNumber + "]";
	}

	
	


}
