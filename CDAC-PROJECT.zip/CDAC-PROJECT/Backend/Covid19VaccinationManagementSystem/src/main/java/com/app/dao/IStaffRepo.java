package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Admin;
import com.app.pojos.Staff;
import com.app.pojos.User;

public interface IStaffRepo extends JpaRepository<Staff,Integer>{
	
	Optional<Staff> findDistinctByEmailAndPassword(String username,String password);
	Optional<Staff> findByEmail(String email);

}
