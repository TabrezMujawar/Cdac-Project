package com.app.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IAdminRepo;
import com.app.dao.IVaccinationDetailsRepo;
import com.app.exceptions.ExceptionHandling;
import com.app.pojos.Admin;
import com.app.pojos.VaccinationDetails;
@Service
@Transactional
public class VaccinationServiceImpl implements IVaccinationDetailsService {
            //dependency injection
	        @Autowired
	       private IVaccinationDetailsRepo vdRepo;
	        @Autowired
	        private IAdminRepo adminRepo;
	       
	
	@Override
	public VaccinationDetails storeVaccinationDetails(VaccinationDetails vd) {
	      // Optional<Admin> opAdmin=adminRepo.findById(admin_id);
	     //  Admin admin=opAdmin.orElseThrow(()->new ExceptionHandling("Invalid admin id"));
	      // admin.addVaccinationDetails(vd);
	       return vdRepo.save(vd);
	}

	@Override
	public List<VaccinationDetails> getAllVaccinationDetails() {
	   return vdRepo.findAll();
	}

	@Override
	public VaccinationDetails getVaccinationDetailsById(int vd_id) {
		Optional<VaccinationDetails> opVaccinationDetails= vdRepo.findById(vd_id);
        VaccinationDetails vd=opVaccinationDetails.orElseThrow(()->new ExceptionHandling("Invalid vaccination details id"));
		return vd;
	}
	
	@Override
	public VaccinationDetails updateVaccinationDetails(int vd_id, VaccinationDetails vd) {
		//Optional<Admin> opAdmin=adminRepo.findById(admin_id);
	   // Admin admin=opAdmin.orElseThrow(()->new ExceptionHandling("Invalid admin id"));
		Optional<VaccinationDetails> opVaccinationDetails= vdRepo.findById(vd_id);
        VaccinationDetails up_vd=opVaccinationDetails.orElseThrow(()->new ExceptionHandling("Invalid vaccination details id"));
        return vdRepo.save(vd);
	}

	@Override
	public VaccinationDetails deleteVaccinationDetailsById(int vd_id) {
		Optional<VaccinationDetails> opVaccinationDetails= vdRepo.findById(vd_id);
        VaccinationDetails delvd=opVaccinationDetails.orElseThrow(()->new ExceptionHandling("Invalid vaccination details id"));
		vdRepo.deleteById(vd_id);
		return delvd;
	}

}
