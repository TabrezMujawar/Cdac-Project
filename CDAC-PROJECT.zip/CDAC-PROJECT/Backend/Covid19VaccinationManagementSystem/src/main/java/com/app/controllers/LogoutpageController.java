package com.app.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AdminDTO;
import com.app.dto.ResponseDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserDTO;
import com.app.pojos.Admin;
import com.app.pojos.Staff;
import com.app.pojos.User;


@RestController
@RequestMapping("/logout")
@CrossOrigin
public class LogoutpageController {
	    
    public LogoutpageController() {
		  System.out.println("In constr of LogoutPageController");
	}
    //logout page invalidating session
    @GetMapping
    public ResponseEntity<?> logoutPage(HttpSession session,Model map)
    {
      map.addAttribute("details",session.getAttribute("details"));
      session.invalidate();
      Object o= map.getAttribute("details");
    System.out.println("Class Name : "+o.getClass());
      if(o instanceof Admin)
      {
    	  System.out.println("In instance of admin");
    	  AdminDTO admin_dto=new AdminDTO();
    	  BeanUtils.copyProperties(o,admin_dto);
    	  return ResponseEntity.ok(new ResponseDTO<>(admin_dto));
      }
      if(o instanceof User)
      {
    	  System.out.println("In instance of user");
    	  UserDTO user_dto=new UserDTO();
    	  BeanUtils.copyProperties(o,user_dto);
    	  return ResponseEntity.ok(new ResponseDTO<>(user_dto));
      }
      if(o instanceof Staff)
      {
    	  System.out.println("In instance of staff");
    	   StaffDTO staff_dto=new StaffDTO();
    	   BeanUtils.copyProperties(o,staff_dto);
    	   return ResponseEntity.ok(new ResponseDTO<>(staff_dto));
      }
      else
    	  return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    	  
    }

}