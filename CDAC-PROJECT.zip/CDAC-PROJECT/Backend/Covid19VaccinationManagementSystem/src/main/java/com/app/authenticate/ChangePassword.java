package com.app.authenticate;

import com.app.enums.Role;

public class ChangePassword {
	    private Role role;
	    private String email;
	    private String oldPassword;
        private String newPassword;
        
	   public ChangePassword() {
		 System.out.println("In constr changePassword dto");
	   }

	public ChangePassword(Role role, String email, String oldPassword, String newPassword) {
		super();
		this.role = role;
		this.email = email;
		this.oldPassword = oldPassword;
		this.newPassword = newPassword;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	@Override
	public String toString() {
		return "ChangePassword [role=" + role + ", email=" + email + ", oldPassword=" + oldPassword
				+ ", newPassword=" + newPassword + "]";
	}

	  
}
