package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IAdminRepo;
import com.app.dao.IStaffRepo;
import com.app.dto.ChangePasswordDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserDTO;
import com.app.exceptions.ExceptionHandling;
import com.app.pojos.Admin;
import com.app.pojos.Staff;
import com.app.pojos.User;

@Service
@Transactional
public class StaffServiceImpl implements IStaffService {
                //dependency injection
	            @Autowired
	            private IStaffRepo staffRepo;
	            @Autowired
	            private IAdminRepo adminRepo;
	            @Autowired
	            private EntityManager mgr;
	            
	 
	
	@Override
	public StaffDTO registerStaff(int admin_id,Staff s) {
		Optional<Admin> opAdmin= adminRepo.findById(admin_id);
		Admin a= opAdmin.orElseThrow(()->new ExceptionHandling("Invalid admin id"));
		 a.addStaff(s);
		 Staff staff= staffRepo.save(s);
		 StaffDTO staff_dto=new StaffDTO();
		//BeanUtils.copyProperties api is used to copy persistent staff to staff dto ( data transfer object )
	     BeanUtils.copyProperties(staff,staff_dto);//takes matching data members and ignores unmatching;
		 return staff_dto;
	}

	@Override
	public StaffDTO authenticateStaff(String username, String password) {
		 /*String jpql="select a from Staff a where a.email=:username and a.password=:password";
	     Optional<Staff> opStaff=Optional.of(mgr.createQuery(jpql,Staff.class).setParameter("username",username).setParameter("password",password).getSingleResult());
	     return  opStaff.orElseThrow(()->new ExceptionHandling("Invalid username or password"));*/
		Staff staff= staffRepo.findDistinctByEmailAndPassword(username, password).orElseThrow(()->new ExceptionHandling("Invalid username or password"));
		StaffDTO staff_dto=new StaffDTO();
		//BeanUtils.copyProperties api is used to copy persistent staff to staff dto ( data transfer object )
	    BeanUtils.copyProperties(staff,staff_dto);//takes matching data members and ignores unmatching;
		return staff_dto;
	}

	@Override
	public ChangePasswordDTO changePassword(String email, String oldPassword, String newPassword) {
		 Staff staff=staffRepo.findDistinctByEmailAndPassword(email,oldPassword).orElseThrow(()->new ExceptionHandling("Invalid username or password"));
	     staff.setPassword(newPassword);
	     Staff s=staffRepo.save(staff);
	     ChangePasswordDTO cp=new ChangePasswordDTO();
	     BeanUtils.copyProperties(s,cp);
	     return cp;
	}
	
	@Override
	public StaffDTO getStaffById(int staffid) {
		Optional<Staff> opStaff= staffRepo.findById(staffid);
		Staff staff= opStaff.orElseThrow(()->new ExceptionHandling("Invalid staff id"));
		StaffDTO staff_dto=new StaffDTO();
		//BeanUtils.copyProperties api is used to copy persistent staff to staff dto ( data transfer object )
	    BeanUtils.copyProperties(staff,staff_dto);//takes matching data members and ignores unmatching;
		return staff_dto;
	}
	
	//forget password
	@Override
	public StaffDTO forgetPassword(String email, String newPassword) {
		Staff s=staffRepo.findByEmail(email).orElseThrow(()-> new ExceptionHandling("Invalid email id"));
		s.setPassword(newPassword);
		StaffDTO staff_dto=new StaffDTO();
		//BeanUtils.copyProperties api is used to copy persistent staff to staff dto ( data transfer object )
	    BeanUtils.copyProperties(s,staff_dto);//takes matching data members and ignores unmatching;
		return staff_dto;
	}

	@Override
	public StaffDTO getByEmail(String email) {
		Staff s=staffRepo.findByEmail(email).orElseThrow(()->new ExceptionHandling("Invalid email"));
		StaffDTO staff_dto=new StaffDTO();
		   BeanUtils.copyProperties(s,staff_dto);
		   return staff_dto;
	    
	}

	@Override
	public List<StaffDTO> getAllStaff() {
		List<Staff> staffList= staffRepo.findAll();
		List<StaffDTO> list=new ArrayList<>();
		staffList.forEach(s -> {
			StaffDTO staff_dto=new StaffDTO();
		    BeanUtils.copyProperties(s,staff_dto);
		    list.add(staff_dto);
		});
		return list;
	}

	@Override
	public StaffDTO updateStaffDetails(int staffid, StaffDTO staffDTO) {
		Optional<Staff> opStaff= staffRepo.findById(staffid);
		Staff upstaff= opStaff.orElseThrow(()->new ExceptionHandling("Invalid staff id"));
	    StaffDTO staff_dto=new StaffDTO();
	    BeanUtils.copyProperties(staffDTO,upstaff,"password");
	    Admin a=upstaff.getS_admin();
	    a.addStaff(upstaff);
	    Staff s= staffRepo.save(upstaff);//persist
	    System.out.println("Staff "+s);
	    StaffDTO sd=new StaffDTO();
	    BeanUtils.copyProperties(s,sd);
		return sd;
	    
	}

	@Override
	public StaffDTO deleteStaffById(int ad_id,int staffid) {
		Optional<Admin> opAdmin= adminRepo.findById(ad_id);
		Admin a= opAdmin.orElseThrow(()->new ExceptionHandling("Invalid admin id"));
		Optional<Staff> opStaff= staffRepo.findById(staffid);
		Staff delstaff= opStaff.orElseThrow(()->new ExceptionHandling("Invalid staff id"));
		a.removeStaff(delstaff);
        staffRepo.deleteById(staffid);
	    StaffDTO staff_dto=new StaffDTO();
      //BeanUtils.copyProperties api is used to copy persistent staff to staff dto ( data transfer object )
	    BeanUtils.copyProperties(delstaff,staff_dto);//takes matching data members and ignores unmatching;
		return staff_dto;
	}
     
	
	
	
}
