package com.app.enums;

public enum Role {
	   
	ADMIN,
	STAFF,
	USER
	

}
