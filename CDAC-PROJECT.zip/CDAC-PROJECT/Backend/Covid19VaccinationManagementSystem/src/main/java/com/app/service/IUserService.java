package com.app.service;

import java.util.List;

import com.app.dto.AdminDTO;
import com.app.dto.ChangePasswordDTO;
import com.app.dto.UserDTO;
import com.app.pojos.User;

public interface IUserService {
	
	    //user registration
		UserDTO registerUser(User u);
		//user login/authentication
		UserDTO authenticateUser(String username,String password);
		//change password
	    ChangePasswordDTO changePassword(String email,String oldPassword,String newPassword);
		//get user by id
		UserDTO getUserById(int userid);
		//get user by aadhar number
		UserDTO getUserByAadharNumber(String aadhar_number);
		//get user by email
	    UserDTO getByEmail(String email);
	    //forget Password
	    UserDTO forgetPassword(String email,String newPassword);
		//get all users
		List<UserDTO> getAllUsers();
		//update user details
		UserDTO updateUserDetails(int userid,UserDTO user);
		//delete user by id
		UserDTO deleteUserById(int userid);
		

}
