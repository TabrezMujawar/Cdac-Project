package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.format.annotation.DateTimeFormat;

import com.app.enums.Role;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Integer id;
	@Column(length = 20)
	private String medical_history;
	@Column(length = 40)
	private String name;
	@DateTimeFormat(pattern = "dd-mm-yyyy")
	private LocalDate dob;
	@Column(length = 20)
	private String gender;
	@Column(length = 40,unique = true)
	private String email;
	@Column(length = 20,nullable = false)
	private String password;
	@Column(length = 40 )
	private String address;
	@Column(length = 10,nullable = false)
	private String contact_no;
	@Column(length = 20,unique = true,name="aadharNumber")
	private String aadharNumber;
	@OneToOne(mappedBy = "user",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.LAZY)
	@JsonIgnoreProperties("user")
	private Appointment appointment;	
	public User()
	{
		System.out.println("In constr of User");
	}

	public User(String medical_history, String name, LocalDate dob, String gender, String email, String password,
			String address, String contact_no, String aadharNumber) {
		super();
		this.medical_history = medical_history;
		this.name = name;
		this.dob = dob;
		this.gender = gender;
		this.email = email;
		this.password = password;
		this.address = address;
		this.contact_no = contact_no;
		this.aadharNumber = aadharNumber;
	
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMedical_history() {
		return medical_history;
	}

	public void setMedical_history(String medical_history) {
		this.medical_history = medical_history;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	//helper method for adding appointment
	public void addAppointment(Appointment a)
	{
		this.setAppointment(a);
		a.setUser(this);
	}

	//helper method for removing appointment
		public void removeAppointment(Appointment a)
		{
			this.setAppointment(null);
			a.setUser(null);
		}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", medical_history=" + medical_history + ", name=" + name + ", dob=" + dob
				+ ", gender=" + gender + ", email=" + email + ", password=" + password + ", address=" + address
				+ ", contact_no=" + contact_no + ", aadharNumber=" + aadharNumber + "]";
	}
	
	
	
}
