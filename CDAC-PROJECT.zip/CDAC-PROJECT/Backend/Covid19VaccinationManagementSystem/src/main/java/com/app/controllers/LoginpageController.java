package com.app.controllers;


import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.authenticate.LoginRequest;
import com.app.dto.AdminDTO;
import com.app.dto.ResponseDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserDTO;
import com.app.enums.Role;
import com.app.pojos.Admin;
import com.app.pojos.Staff;
import com.app.pojos.User;
import com.app.service.IAdminService;
import com.app.service.IStaffService;
import com.app.service.IUserService;


@RestController
@RequestMapping("/login")
@CrossOrigin
public class LoginpageController {
	          //dependency injection
	          @Autowired
	          private IAdminService adminService;
	          @Autowired
	          private IUserService userService;
	          @Autowired
	          private IStaffService staffService;
	          
	          public LoginpageController() {
				  System.out.println("In constr of LoginPageController");
			}
	          
	
	          //add REST request handling method to authenticate 
	           @PostMapping
	           public ResponseEntity<?> loginRequest(@RequestBody LoginRequest authenticateUser,HttpSession session)
	           {
	        	   LoginRequest authUser=authenticateUser;
	        	   //checking authentication data
	        	   System.out.println(authUser);
	        	   String role=authUser.getRole().toString();
	        	   if(role.equals("ADMIN"))
	        	   {
	        	    AdminDTO a=adminService.authenticateAdmin(authUser.getUsername(),authUser.getPassword());
	        	    session.setAttribute("details",a);
	        	    AdminDTO admin_dto=new AdminDTO();
	        		 //BeanUtils.copyProperties api is used to copy persistent admin to admin dto
	        		BeanUtils.copyProperties(a,admin_dto);//takes matching data members and ignore unmatching
	        	    return ResponseEntity.ok(new ResponseDTO<>(admin_dto));
	        	   }
	        	   else if(role.equals("USER"))
	        	     {
	        		   UserDTO u=userService.authenticateUser(authUser.getUsername(),authUser.getPassword());
	        		   session.setAttribute("details",u);
	        		   UserDTO user_dto=new UserDTO();
	        			 //BeanUtils.copyProperties api is used to copy persistent user to user dto
	        	       BeanUtils.copyProperties(u,user_dto);//takes matching data members and ignores unmatching;
	        		   return ResponseEntity.ok(new ResponseDTO<>(user_dto));
	        	     }	 
	        	    else if(role.equals("STAFF"))
	        	      {
	        		   StaffDTO s=staffService.authenticateStaff(authUser.getUsername(),authUser.getPassword());
	        		   session.setAttribute("details",s);
	        		   StaffDTO staff_dto=new StaffDTO();
	        			//BeanUtils.copyProperties api is used to copy persistent staff to staff dto ( data transfer object )
	        			 BeanUtils.copyProperties(s,staff_dto);//takes matching data members and ignores unmatching;
	        		   return ResponseEntity.ok(new ResponseDTO<>(staff_dto));
	        	      }
	        	   else {
	      
	        		   return new ResponseEntity<>(HttpStatus.NOT_FOUND);	        		  
	        	   }    

	           }
	        	   
	    
	          
	          

}
