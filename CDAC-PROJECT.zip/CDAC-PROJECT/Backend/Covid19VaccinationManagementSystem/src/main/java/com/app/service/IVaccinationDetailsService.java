package com.app.service;

import java.util.List;

import com.app.pojos.VaccinationDetails;

public interface IVaccinationDetailsService {
         
	//store vaccination details
	VaccinationDetails storeVaccinationDetails(VaccinationDetails vd);
	//get all vaccination details
	List<VaccinationDetails> getAllVaccinationDetails();
	//get vaccination details by id
	VaccinationDetails getVaccinationDetailsById(int vd_id);
	//update vaccination details
	VaccinationDetails updateVaccinationDetails(int vd_id,VaccinationDetails vd);
	//delete vaccination details
	VaccinationDetails deleteVaccinationDetailsById(int vd_id);
	
	
}
