package com.app.exceptions;

@SuppressWarnings("serial")
public class ExceptionHandling extends RuntimeException{
	  public ExceptionHandling(String mesg)
	  {
		  super(mesg);
	  }

}
