package com.app.controllers;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Appointment;
import com.app.pojos.User;
import com.app.service.IAppointmentService;

@RestController
@RequestMapping("/appointment")
@CrossOrigin
public class AppointmentController {
	               //dependency injection
	               @Autowired
	               private IAppointmentService appService;
	               
	               public AppointmentController() {
					System.out.println("In constr of Appointment Service");
				   }
	             
	            //book an appointment
	             @PostMapping("/{us_id}")
	             public ResponseEntity<?> bookAppointment(@PathVariable int us_id,@RequestBody Appointment app) 
	             {
	            	 System.out.println("In book appointment ");
		            return new ResponseEntity<>(appService.bookAppointment(us_id,app),HttpStatus.CREATED);
		        	  
	             }
	             
	             //get appointment by id
	             @GetMapping("/{app_id}")
	             public ResponseEntity<?> getAppointmentById(@PathVariable int app_id)
	             {
	            	 System.out.println("In  get appointment by id ");
	            	 return new ResponseEntity<>(appService.getAppointmentById(app_id),HttpStatus.OK);
	             }
	               
	             //get all appointment
	             @GetMapping
	             public ResponseEntity<?> getAllAppointment()
	             {
	            	 System.out.println("In get all appointment");
	            	 return new ResponseEntity<>(appService.getAllAppointments(),HttpStatus.OK);
	             }
	             
	             //delete appointment
	            @DeleteMapping("/{u_id}/{app_id}")
	            public ResponseEntity<?> deleteAppointmentById(@PathVariable int u_id,@PathVariable int app_id)
	            {
	            	 System.out.println("In delete appointment details");
		        	  
		             return new ResponseEntity<>(appService.deleteAppointmentById(u_id,app_id),HttpStatus.OK);
		    
	            }
	             
	             
	             
	             

}
