package com.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AdminDTO;
import com.app.dto.ResponseDTO;
import com.app.pojos.Admin;
import com.app.service.IAdminService;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

	           //dependency injection
	           @Autowired
	           private IAdminService adminService;
	           
	           public  AdminController() {
		           System.out.println("In constr of AdminController"+getClass().getName());
	           }
	           
	           @GetMapping("/{adminId}")
	           public ResponseEntity<?> getadminbyId(@PathVariable int adminId)
	           {
	        	  System.out.println("In get admin by id");
	        	  return ResponseEntity.ok(new ResponseDTO<>(adminService.getAdminbyid(adminId)));
	           }
	       
	           //add REST request handling method to add register admin
	           @PostMapping()
	           //response entity return status,header and body
	           //Admin
	           public ResponseEntity<?> registerAdmin(@RequestBody Admin admin)
	           {
	        	  System.out.println("In register admin");
	        	  return ResponseEntity.ok(new ResponseDTO<>(adminService.registerAdmin(admin)));
	           }
	        
	          
	           
	           @PutMapping("{a_id}")
	           public ResponseEntity<?> updateAdmin(@PathVariable int a_id,@RequestBody AdminDTO admin)
	           {
	        	  System.out.println("In update admin");
	        	  return ResponseEntity.ok(new ResponseDTO<>(adminService.updateAdmin(a_id,admin)));
	           }
	          
	           @DeleteMapping("{aid}")
	           public ResponseEntity<?> deleteAdmin(@PathVariable int aid)
	           {
	        	  System.out.println("In delete admin");
	        	  return ResponseEntity.ok(new ResponseDTO<>(adminService.deleteAdmin(aid)));
	           }
	           
	
	
	

}
