package com.app.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ResponseDTO;
import com.app.dto.UserDTO;
import com.app.pojos.Admin;
import com.app.pojos.User;
import com.app.service.IUserService;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {
	           
	         //dependency injection
	         @Autowired
	         private IUserService userService;
	         
	         public UserController() {
				System.out.println("In constr of UserController");
			 }
	         
	         //register user
	         @PostMapping
	         public ResponseEntity<?> registerUser(@RequestBody User user)
	         {
	        	 System.out.println("In register user");
	        	 return ResponseEntity.ok(new ResponseDTO<>(userService.registerUser(user)));	
	         }
	         
	         //get all users
	         @GetMapping
	         public ResponseEntity<?> getAllUsers() 
	         {
	        	 System.out.println("In get all user");
	        	 return ResponseEntity.ok(new ResponseDTO<>(userService.getAllUsers()));	
	         }
	         
	         //get user by id
	         @GetMapping("/{userid}")
	         public ResponseEntity<?> getUserById(@PathVariable int userid)
	         {
	        	 System.out.println("In get User By Id");
	        	 return ResponseEntity.ok(new ResponseDTO<>(userService.getUserById(userid)));	        	 
	         }
	         //get user by aadhar number
	         @GetMapping("/details/{aadhar_no}")
	         public ResponseEntity<?> getUserByAadharNumber(@PathVariable String aadhar_no)
	         {
	        	 System.out.println("In get user by aadhar number"); 
	        	 return ResponseEntity.ok(new ResponseDTO<>(userService.getUserByAadharNumber(aadhar_no)));
	         }
	         
	         //update user details
	         @PutMapping("/{uid}")
	         public ResponseEntity<?> updateUserDetails(@PathVariable int uid,@RequestBody UserDTO userdetails)
	         {
	        	 System.out.println("In update user details");
	        	 return ResponseEntity.ok(new ResponseDTO<>(userService.updateUserDetails(uid,userdetails)));
	         }
	    
	         //delete user
	         @DeleteMapping("/{user_id}")
	         public ResponseEntity<?> deleteUserDetails(@PathVariable int user_id)
	         {
	        	 System.out.println("In delete user details");
	             return ResponseEntity.ok(new ResponseDTO<>(userService.deleteUserById(user_id)));
	        	   	 
	         }
	         

}
