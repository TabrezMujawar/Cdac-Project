package com.app.pojos;

import javax.persistence.*;

import com.app.enums.PharmaCompanies;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="vaccination_details")
public class VaccinationDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "vaccination_user_id")
	private Integer id;
	@Column(length = 12,nullable = false,unique = true)
	private String aadhar_number;
	@Enumerated(EnumType.STRING)
	@Column(name="pharma_company",length = 20,nullable = false)
	private PharmaCompanies pharmaceutical_company;
	public VaccinationDetails()
	{
		System.out.println("In constr of VaccinationDetails");
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAadhar_number() {
		return aadhar_number;
	}

	public void setAadhar_number(String aadhar_number) {
		this.aadhar_number = aadhar_number;
	}

	public PharmaCompanies getPharmaceutical_company() {
		return pharmaceutical_company;
	}


	public void setPharmaceutical_company(PharmaCompanies pharmaceutical_company) {
		this.pharmaceutical_company = pharmaceutical_company;
	}

	
	@Override
	public String toString() {
		return "VaccinationDetails [id=" + id + ", aadharNumber=" + aadhar_number + ", pharmaceutical_company="
				+ pharmaceutical_company + "]";
	}


}
