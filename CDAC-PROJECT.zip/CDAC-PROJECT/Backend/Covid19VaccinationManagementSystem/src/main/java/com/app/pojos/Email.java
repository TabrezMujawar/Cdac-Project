package com.app.pojos;

import com.app.enums.Role;

public class Email {
	private Role role;
	private String destEmail;
	private String message;
	private String subject;
	
	 public Email() {
	System.out.println("In email");
	}
	 
	 
	
	public Email(Role role, String destEmail, String message, String subject) {
		super();
		this.role = role;
		this.destEmail = destEmail;
		this.message = message;
		this.subject = subject;
	}


	

	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getDestEmail() {
		return destEmail;
	}
	public void setDestEmail(String destEmail) {
		this.destEmail = destEmail;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}



	@Override
	public String toString() {
		return "Email [role=" + role + ", destEmail=" + destEmail + ", message=" + message + ", subject=" + subject
				+ "]";
	}
	
	
	

}
