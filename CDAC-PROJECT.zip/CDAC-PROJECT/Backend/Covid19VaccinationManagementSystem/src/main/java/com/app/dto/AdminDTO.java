package com.app.dto;

public class AdminDTO {
	private Integer id;
	private String name;
	private String email;
	private String address;
	private String contact_no;
	
	public AdminDTO() {
		System.out.println("In admin dto");	
	}

	public AdminDTO(Integer id, String name, String email, String address, String contact_no) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.address = address;
		this.contact_no = contact_no;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	
	
	@Override
	public String toString() {
		return "AdminDTO [id=" + id + ", name=" + name + ", email=" + email + ", address=" + address + ", contact_no="
				+ contact_no + "]";
	}

	

	
	
	
	
	

}
