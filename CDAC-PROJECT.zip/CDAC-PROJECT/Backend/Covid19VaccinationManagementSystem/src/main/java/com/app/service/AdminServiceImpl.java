package com.app.service;

import java.util.Optional;


import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.dao.IAdminRepo;
import com.app.dto.AdminDTO;
import com.app.dto.ChangePasswordDTO;
import com.app.dto.StaffDTO;
import com.app.enums.Role;
import com.app.exceptions.ExceptionHandling;
import com.app.pojos.Admin;
import com.app.pojos.Staff;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {
               //dependency injection
	      @Autowired
	      private IAdminRepo adminRepo;
	      @Autowired
	      private EntityManager mgr;
	
	@Override
	public AdminDTO registerAdmin(Admin a) {
		 Admin admin= adminRepo.save(a);
		 AdminDTO admin_dto=new AdminDTO();
		 //BeanUtils.copyProperties api is used to copy persistent admin to admin dto
		 BeanUtils.copyProperties(admin,admin_dto);
		 return admin_dto;
	}
	


	@Override
	public AdminDTO authenticateAdmin(String username,String password) {
		/* String jpql="select a from Admin a where a.email=:username and a.password=:password";
	     Optional<Admin> opAdmin=Optional.of(mgr.createQuery(jpql,Admin.class).setParameter("username",username).setParameter("password",password).getSingleResult());
	     return  opAdmin.orElseThrow(()->new ExceptionHandling("Invalid username or password"));*/
	   Admin admin=adminRepo.findDistinctByEmailAndPassword(username,password).orElseThrow(()->new ExceptionHandling("Invalid username or password"));
	   AdminDTO admin_dto=new AdminDTO();
	   BeanUtils.copyProperties(admin,admin_dto);
	   return admin_dto;
	}
	
	@Override
	public ChangePasswordDTO changePassword(String email, String oldPassword, String newPassword) 
	{
	 System.out.println("In change password of admin");
	 Admin admin=adminRepo.findDistinctByEmailAndPassword(email,oldPassword).orElseThrow(()->new ExceptionHandling("Invalid username or password"));
     System.out.println("ADMIN : "+admin);
	 admin.setPassword(newPassword);
     Admin a=adminRepo.save(admin);
     ChangePasswordDTO cp=new ChangePasswordDTO();
     BeanUtils.copyProperties(a,cp);
     return cp;
	}
	
	
	@Override
	public AdminDTO getByEmail(String email) {
		Admin a=adminRepo.findByEmail(email).orElseThrow(()->new ExceptionHandling("Invalid email"));
		 AdminDTO admin_dto=new AdminDTO();
		   BeanUtils.copyProperties(a,admin_dto);
		   return admin_dto;
	    
	}

	//forget password
	@Override
	public AdminDTO forgetPassword(String email, String newPassword) {
		Admin a=adminRepo.findByEmail(email).orElseThrow(()-> new ExceptionHandling("Invalid email id"));
		System.out.println(a);
		a.setPassword(newPassword);
		 AdminDTO admin_dto=new AdminDTO();
		   BeanUtils.copyProperties(a,admin_dto);
		   return admin_dto;
	}



	@Override
	public AdminDTO updateAdmin(int adminId, AdminDTO adminDTO) {
		Optional<Admin> opAdmin= adminRepo.findById(adminId);
		Admin upadmin= opAdmin.orElseThrow(()->new ExceptionHandling("Invalid admin id"));
		BeanUtils.copyProperties(adminDTO,upadmin,"password");
		Admin admin=adminRepo.save(upadmin);
		AdminDTO admin_dto=new AdminDTO();
	    BeanUtils.copyProperties(admin,admin_dto);
		return admin_dto;
	}
	
	

	@Override
	public AdminDTO getAdminbyid(int adminId) {
		Optional<Admin> opAdmin= adminRepo.findById(adminId);
		Admin admin= opAdmin.orElseThrow(()->new ExceptionHandling("Invalid admin id"));
		AdminDTO admin_dto=new AdminDTO();
	    BeanUtils.copyProperties(admin,admin_dto);
		return admin_dto;
	}



	@Override
	public AdminDTO deleteAdmin(int adminId) {
		Optional<Admin> opAdmin= adminRepo.findById(adminId);
		Admin deladmin= opAdmin.orElseThrow(()->new ExceptionHandling("Invalid admin id"));
		adminRepo.deleteById(adminId);
		AdminDTO admin_dto=new AdminDTO();
	    BeanUtils.copyProperties(deladmin,admin_dto);
	    return admin_dto;
	}
	
	

}
