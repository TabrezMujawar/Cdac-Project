package com.app.controllers;

import javax.annotation.PostConstruct;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.authenticate.ForgetPassword;
import com.app.dao.IAdminRepo;
import com.app.dao.IStaffRepo;
import com.app.dao.IUserRepo;
import com.app.dto.AdminDTO;
import com.app.dto.ResponseDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserDTO;
import com.app.exceptions.ExceptionHandling;
import com.app.pojos.Admin;
import com.app.pojos.Email;
import com.app.pojos.Staff;
import com.app.pojos.User;
import com.app.service.IAdminService;
import com.app.service.IStaffService;
import com.app.service.IUserService;

@RestController
@RequestMapping("/reset")
@CrossOrigin
public class SendMailController {
	@Autowired
	private JavaMailSender sender;
	
	@Autowired
	private IAdminService adminService;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IStaffService staffService;
	

	
	
	@PostConstruct
	public void init()
	{
		System.out.println("in init "+sender);
	}
	
	
	@PostMapping
	public ResponseEntity<?> processForm(@RequestBody Email em)
	{
		SimpleMailMessage mesg=new SimpleMailMessage();
	     if(em.getRole().toString().equals("ADMIN"))
	     {
	    	 try {
	    		 AdminDTO a= adminService.getByEmail(em.getDestEmail());
	    			mesg.setTo(em.getDestEmail());
	    			mesg.setSubject(em.getSubject());
	    			mesg.setText(em.getMessage());
	    			sender.send(mesg);
	    			return new ResponseEntity<>(em.getDestEmail(),HttpStatus.OK);
	    	 }
	    	 catch(Exception e)
	    	 {
	    		 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    	 }
	     }
	     else if(em.getRole().toString().equals("USER"))
	     {
	    	 try {
	    		 UserDTO u= userService.getByEmail(em.getDestEmail());
	    		
	    			mesg.setTo(em.getDestEmail());
	    			mesg.setSubject(em.getSubject());
	    			mesg.setText(em.getMessage());
	    			 System.out.println(em);
	    			sender.send(mesg);
	    			return new ResponseEntity<>(em.getDestEmail(),HttpStatus.OK);
	    	 }
	    	 catch(Exception e)
	    	 {
	    		 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    	 }
	     }
	     
	     else if(em.getRole().toString().equals("STAFF"))
	     {
	    	 try {
	    		   StaffDTO s= staffService.getByEmail(em.getDestEmail());
	    			mesg.setTo(em.getDestEmail());
	    			mesg.setSubject(em.getSubject());
	    			mesg.setText(em.getMessage());
	    			sender.send(mesg);
	    			return new ResponseEntity<>(em.getDestEmail(),HttpStatus.OK);
	    	 }
	    	 catch(Exception e)
	    	 {
	    		 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    	 }
	     }
	     
	     else
	    	 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		
	
	}
	

	@PostMapping("/password")
	public ResponseEntity<?> changPassword(@RequestBody ForgetPassword fg)
	{
		if(fg.getRole().toString().equals("ADMIN"))
		{
			 return ResponseEntity.ok(new ResponseDTO<>(adminService.forgetPassword(fg.getEmail(), fg.getNewPassword())));
		}
		else if(fg.getRole().toString().equals("USER"))
		{
			
			 return ResponseEntity.ok(new ResponseDTO<>(userService.forgetPassword(fg.getEmail(), fg.getNewPassword())));

		}
		else if(fg.getRole().toString().equals("STAFF"))
		{
			
			 return ResponseEntity.ok(new ResponseDTO<>(staffService.forgetPassword(fg.getEmail(), fg.getNewPassword())));

		}
		
		else
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

			
	}
	
}
