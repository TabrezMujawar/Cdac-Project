package com.app.service;

import java.sql.SQLException;
import java.util.List;

import com.app.pojos.Appointment;

public interface IAppointmentService {
	//book appointment
	Appointment bookAppointment(int user_id,Appointment a);
	//get appointment by id
	Appointment getAppointmentById(int app_id);
	//get all appointments
	List<Appointment> getAllAppointments();
	//delete appointment
	Appointment deleteAppointmentById(int uid,int app_id);

}
