package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.app.enums.Role;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="admin")
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(length = 40)
	private String name;
	@Column(length = 40,unique = true)
	private String email;
	@Column(length = 20,nullable = false)
	private String password;
	@Column(length = 40 )
	private String address;
	@Column(length = 12,nullable = false)
	private String contact_no;
	@OneToMany(mappedBy = "s_admin",cascade = CascadeType.ALL,orphanRemoval = true)
	@JsonIgnore
	private List<Staff> staffList=new ArrayList<>();

	public Admin()
	{
		System.out.println("In constr of Admin");
	}

	public Admin(String name, String email, String password, String address, String contact_no) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.address = address;
		this.contact_no = contact_no;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public List<Staff> getStaffList() {
		return staffList;
	}

	public void setStaffList(List<Staff> staffList) {
		this.staffList = staffList;
	}
	
	

	//helper method for adding staff
	public void addStaff(Staff s)
	{
		staffList.add(s);
		s.setS_admin(this);
	}
	
	//helper method for removing staff
		public void removeStaff(Staff s)
		{
			staffList.remove(s);
			s.setS_admin(null);
		}
	
	
	
	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", address="
				+ address + ", contact_no=" + contact_no + ", role=" + "]";
	}
	
	
	
	

}
