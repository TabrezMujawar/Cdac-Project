package com.app.controllers;


import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dto.ResponseDTO;
import com.app.dto.StaffDTO;
import com.app.pojos.Admin;
import com.app.pojos.Staff;
import com.app.service.IStaffService;

@RestController
@RequestMapping("/staff")
@CrossOrigin
public class StaffController {
              
	          //dependency injection
	          @Autowired
	          private IStaffService staffService;
	          
	          public StaffController() {
				System.out.println("In staff controller");
			}
	  
	          //register staff
		         @PostMapping("/{id}")
		         public ResponseEntity<?> registerStaff(@RequestBody Staff staff,@PathVariable int id)
		         {
		        	 System.out.println("In register staff");
		             return ResponseEntity.ok(new ResponseDTO<>(staffService.registerStaff(id,staff)));
		         }
		         
		         //get all staff
		         @GetMapping
		         public ResponseEntity<?> getAllStaff() 
		         {
		        	 System.out.println("In get all staff");
		        	 return ResponseEntity.ok(new ResponseDTO<>(staffService.getAllStaff())); 
		         }
		         
		         //get staff by id
		         @GetMapping("/{staffid}")
		         public ResponseEntity<?> getStaffbyid(@PathVariable int staffid)
		         {
		        	 System.out.println("In get staff by id");
		        	 return ResponseEntity.ok(new ResponseDTO<>(staffService.getStaffById(staffid)));  	 
		         }
		         
		         //update staff details
		         @PutMapping("/{staff_id}")
		         public ResponseEntity<?> updateStaffDetails(@PathVariable int staff_id,@RequestBody StaffDTO staffdetails)
		         {
		        	
		        	 System.out.println("In update staff details");
		        	 return ResponseEntity.ok(new ResponseDTO<>(staffService.updateStaffDetails(staff_id,staffdetails)));
		         }
		    
		         //delete staff
		         @DeleteMapping("/{aid}/{sid}")
		         public ResponseEntity<?> deleteStaffDetails(@PathVariable int aid,@PathVariable int sid)
		         {
		        	 System.out.println("In delete staff details");
		        	 return ResponseEntity.ok(new ResponseDTO<>(staffService.deleteStaffById(aid,sid)));
		         }
		         

	
	
}
