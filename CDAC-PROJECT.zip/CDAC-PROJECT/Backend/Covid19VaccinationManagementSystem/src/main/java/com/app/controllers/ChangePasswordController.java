package com.app.controllers;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.authenticate.ChangePassword;
import com.app.dto.AdminDTO;
import com.app.dto.ChangePasswordDTO;
import com.app.dto.ResponseDTO;
import com.app.pojos.Admin;
import com.app.service.IAdminService;
import com.app.service.IStaffService;
import com.app.service.IUserService;

@RestController
@RequestMapping("/changepassword")
@CrossOrigin
public class ChangePasswordController {
               @Autowired
	           private IAdminService adminService;
               @Autowired
	           private IUserService userService;
               @Autowired
	           private IStaffService staffService;
	           
	           public ChangePasswordController() {
				System.out.println("In constr of change password controller");
			}
	        
	           @PostMapping
	           public ResponseEntity<?> chgPassword(@RequestBody ChangePassword cp)
	           {
	        	  String role=cp.getRole().toString();
	        	  System.out.println(cp);
	        	     if(role.equals("ADMIN"))
	        		 {
	        	    	  return ResponseEntity.ok(new ResponseDTO<>(adminService.changePassword(cp.getEmail(),cp.getOldPassword(),cp.getNewPassword())));       		        
	        		  }
	        	     else if(role.equals("USER"))
	        	     {
	        	    	  return ResponseEntity.ok(new ResponseDTO<>(userService.changePassword(cp.getEmail(),cp.getOldPassword(),cp.getNewPassword())));       		        
	        	     }
	        	     else if(role.equals("STAFF"))
                       {
 	        	    	  return ResponseEntity.ok(new ResponseDTO<>(staffService.changePassword(cp.getEmail(),cp.getOldPassword(),cp.getNewPassword())));       		        

                        }
	        	    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        	     
	           }
	           
	           
}
