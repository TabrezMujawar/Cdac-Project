package com.app.enums;

public enum PharmaCompanies {
	BHARAT_BIOTECH,
	SERUM_INSTITUTE,
	ZYDUS_CADILA,
	PANACEA_BIOTECH

}
