package com.app;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.RETURNS_SELF;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.app.controllers.AdminController;
import com.app.controllers.AppointmentController;
import com.app.controllers.ChangePasswordController;
import com.app.controllers.LoginpageController;
import com.app.controllers.LogoutpageController;
import com.app.controllers.StaffController;
import com.app.controllers.UserController;
import com.app.controllers.VaccinationDetailsController;
import com.app.dto.AdminDTO;
import com.app.dto.StaffDTO;
import com.app.dto.UserDTO;
import com.app.pojos.Staff;
import com.app.service.IAdminService;
import com.app.service.IStaffService;
import com.app.service.IUserService;

@SpringBootTest
@AutoConfigureMockMvc
class Covid19VaccinationManagementSystemApplicationTests {
        
	
	
	@Autowired
	private AdminController adminController;
	@Autowired
	private AppointmentController appointmentController;
	@Autowired
	private ChangePasswordController changeController;
	@Autowired
	private LoginpageController loginController;
	@Autowired
	private LogoutpageController logoutController;
	@Autowired
	private StaffController staffController;
	@Autowired
	private UserController userController;
	@Autowired
	private VaccinationDetailsController vaccinationDetailsController;
	
	
	
	@Autowired
	private MockMvc mockMvc;// entry point to testing MVC : simulates HTTP requests.
	
	@MockBean // replaces ProductService by it's mock (method are not delegated to actual
	             // implementation class)
	private IStaffService staffService;
	@MockBean
	private IUserService userService;
	
	@MockBean
	private IAdminService adminService;
	
	@Test
	//unit testing or smoke testing or sanity testing
	void testController() {
		System.out.println("in test");
		
		assertNotNull(adminController);
		assertNotNull(appointmentController);
		assertNotNull(changeController);
		assertNotNull(loginController);
		assertNotNull(logoutController);
		assertNotNull(staffController);
		assertNotNull(userController);
		assertNotNull(vaccinationDetailsController);

	}
	

	//integeration testing
	@Test
	public void testGetStaff() throws Exception {
		StaffDTO s = new StaffDTO(24,"rahul","rahul1@gmail.com","Mumbai","45621565",1);
		when(staffService.getStaffById(24)).thenReturn(s);
		// performs a request get with path var=12
		mockMvc.perform(get("/staff/24")).
		andExpect(jsonPath("result.name").value("rahul")).//in resulting JSON : checks key name n asserts its value 
		andExpect(status().isOk());//chks if HttpStatus is OK
	}
	
	
	@Test
	public void testGetUser() throws Exception {
		UserDTO u = new UserDTO(2,"none","Sara",LocalDate.parse("1997-08-09"),"Female","sara@gmail.com","Pune","1234567892","4223355654");
		when(userService.getUserById(2)).thenReturn(u);
		// performs a request get with path var=12
		mockMvc.perform(get("/user/2")).
		andExpect(jsonPath("result.name").value("Sara")).//in resulting JSON : checks key name n asserts its value 
		andExpect(status().isOk());//chks if HttpStatus is OK
	}
	
	@Test
	public void testGetAdmin() throws Exception {
		AdminDTO a = new AdminDTO(4,"Alia","alia@gmail.com","Mumbai","456656565");
		when(adminService.getAdminbyid(4)).thenReturn(a);
		// performs a request get with path var=12
		mockMvc.perform(get("/admin/4")).
		andExpect(jsonPath("result.name").value("Alia")).//in resulting JSON : checks key name n asserts its value 
		andExpect(status().isOk());//chks if HttpStatus is OK
	}


	
		
		
		
	

}
